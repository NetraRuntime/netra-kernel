#pragma once

/*
 * TQ4 Decode Attention Stage1 — GQA-aware, cp.async-pipelined CUDA kernel (hd=256).
 *
 * Memory-latency bound (the scalar kernel floored at ~6.8% HBM bw): each warp
 * now DOUBLE-BUFFERS the next token tile's packed K/V into smem via cp.async
 * while computing the current tile, hiding HBM load latency so the kernel can
 * approach bandwidth-bound. GQA reuse retained (load each token once, dot vs all
 * QH_TILE q-heads). Uniform centroids -> arithmetic dequant (no smem LUT).
 *
 * Phase 1 (QK):     lane->token; read K tile from smem, dot vs all QH_TILE q-heads.
 * Phase 2 (softmax): per-q-head warp-reduce online softmax.
 * Phase 3 (V accum): lane->dim; read V tile from smem, weighted-accum all q-heads.
 * Writes normalized per-split att_out + att_lse; the stage2 reduce runs in Triton.
 */

#include <sgl_kernel/tensor.h>
#include <sgl_kernel/utils.cuh>

#include <cuda_bf16.h>
#include <cuda_pipeline.h>
#include <mma.h>
#include <float.h>
#include <cstdint>

namespace {

constexpr int HEAD_DIM = 256;
constexpr int PACKED_DIM = 128;       // head_dim / 2 (bytes per token per head)
constexpr int PACKED_VEC = PACKED_DIM / 16;  // 8 uint4 per token
constexpr int BLOCK_N = 32;           // tokens per pipelined tile
constexpr int QH_TILE = 8;            // q-heads per block (GQA group chunk)
constexpr int BLOCK_W = 2;            // warps per block (each owns a split); 2 keeps smem<48KB w/ double-buffer
constexpr int WARP_SIZE = 32;
constexpr int BLOCK_SIZE = BLOCK_W * WARP_SIZE;
constexpr int MIN_BLOCK_KV = 32;
constexpr int PP_PER_LANE = PACKED_DIM / WARP_SIZE;  // 4

__device__ __forceinline__ float warp_reduce_sum(float val) {
#pragma unroll
  for (int offset = 16; offset > 0; offset >>= 1)
    val += __shfl_xor_sync(0xffffffff, val, offset);
  return val;
}

__device__ __forceinline__ float warp_reduce_max(float val) {
#pragma unroll
  for (int offset = 16; offset > 0; offset >>= 1)
    val = fmaxf(val, __shfl_xor_sync(0xffffffff, val, offset));
  return val;
}

__global__ void tq4_decode_stage1_v2(
    const __nv_bfloat16* __restrict__ Q,
    const uint8_t* __restrict__ K_packed,
    const uint8_t* __restrict__ V_packed,
    const __nv_bfloat16* __restrict__ K_dscale,
    const __nv_bfloat16* __restrict__ V_dscale,
    const int32_t* __restrict__ kv_indptr,
    const int64_t* __restrict__ kv_indices,
    const int32_t* __restrict__ num_kv_splits,
    float* __restrict__ att_out,
    float* __restrict__ att_lse,
    const float* __restrict__ k_centroids,
    const float* __restrict__ v_centroids,
    float sm_scale,
    int H_Q, int H_KV, int max_kv_splits,
    int stride_q_batch, int stride_q_head,
    int stride_kp_pool, int stride_kp_head,
    int stride_vp_pool, int stride_vp_head,
    int stride_kds_pool, int stride_vds_pool,
    int stride_att_batch, int stride_att_head, int stride_att_split,
    int kv_group_num) {
  const int batch_id = blockIdx.x;
  const int warp_id = threadIdx.x / WARP_SIZE;
  const int lane_id = threadIdx.x % WARP_SIZE;

  const int chunks_per_kv = (kv_group_num + QH_TILE - 1) / QH_TILE;
  const int kv_head = blockIdx.y / chunks_per_kv;
  const int chunk = blockIdx.y % chunks_per_kv;
  const int qh_base = kv_head * kv_group_num + chunk * QH_TILE;
  const int qh_count = min(QH_TILE, kv_group_num - chunk * QH_TILE);

  const int split_id = blockIdx.z * BLOCK_W + warp_id;

  // bf16-packed (even,odd) per (head, p): the QK dot does 1 __hfma2 instead of 2
  // fp32 FMA per (head, dim). Q is a bf16 input anyway, so no input-precision loss
  // vs the old fp32 copy; the dot accumulates in bf16 per 16-elem chunk then flushes
  // to fp32 (bounds the bf16-accumulate error well under the 0.05 gate).
  __shared__ __nv_bfloat162 s_q_pair[QH_TILE][PACKED_DIM];
  // double-buffered packed K/V tiles (uint4 for 16B cp.async alignment)
  __shared__ uint4 s_K[BLOCK_W][2][BLOCK_N][PACKED_VEC];
  __shared__ uint4 s_V[BLOCK_W][2][BLOCK_N][PACKED_VEC];
  __shared__ float s_kds[BLOCK_W][2][BLOCK_N];
  __shared__ float s_vds[BLOCK_W][2][BLOCK_N];
  __shared__ float s_p[BLOCK_W][QH_TILE][BLOCK_N];

  // Uniform centroids are an affine grid: centroid[c] = c0 + c*step (1 FMA, no LUT).
  const float k_c0 = k_centroids[0];
  const float k_step = (k_centroids[15] - k_centroids[0]) * (1.0f / 15.0f);
  const float v_c0 = v_centroids[0];
  const float v_step = (v_centroids[15] - v_centroids[0]) * (1.0f / 15.0f);

  // Stage Q (even/odd interleaved) for this block's q-head tile.
  for (int idx = threadIdx.x; idx < QH_TILE * PACKED_DIM; idx += BLOCK_SIZE) {
    int h = idx / PACKED_DIM;
    int pp = idx % PACKED_DIM;
    if (h < qh_count) {
      const __nv_bfloat16* q_ptr = Q + batch_id * stride_q_batch + (qh_base + h) * stride_q_head;
      s_q_pair[h][pp] = *reinterpret_cast<const __nv_bfloat162*>(&q_ptr[2 * pp]);
    } else {
      s_q_pair[h][pp] = __floats2bfloat162_rn(0.0f, 0.0f);
    }
  }
  __syncthreads();

  if (split_id >= max_kv_splits) return;

  const int kv_start = kv_indptr[batch_id];
  const int kv_end = kv_indptr[batch_id + 1];
  const int kv_len = kv_end - kv_start;
  const int n_splits = num_kv_splits[batch_id];
  const int split_len = (kv_len + n_splits - 1) / n_splits;
  const int aligned_len = ((split_len + MIN_BLOCK_KV - 1) / MIN_BLOCK_KV) * MIN_BLOCK_KV;
  const int my_start = kv_start + split_id * aligned_len;
  const int my_end = min(my_start + aligned_len, kv_end);

  if (my_start >= kv_end) {
    if (lane_id == 0) {
      for (int h = 0; h < qh_count; h++) {
        int qh = qh_base + h;
        att_lse[batch_id * H_Q * max_kv_splits + qh * max_kv_splits + split_id] = -FLT_MAX;
      }
    }
    return;
  }

  float acc_even[QH_TILE][PP_PER_LANE];
  float acc_odd[QH_TILE][PP_PER_LANE];
  float e_max[QH_TILE];
  float e_sum[QH_TILE];
#pragma unroll
  for (int h = 0; h < QH_TILE; h++) {
    e_max[h] = -FLT_MAX;
    e_sum[h] = 0.0f;
#pragma unroll
    for (int i = 0; i < PP_PER_LANE; i++) {
      acc_even[h][i] = 0.0f;
      acc_odd[h][i] = 0.0f;
    }
  }

  const int num_tiles = (my_end - my_start + BLOCK_N - 1) / BLOCK_N;

// Issue cp.async for one token tile's packed K/V into smem buffer `buf`.
#define TQ4_LOAD_TILE(t, buf)                                                                    \
  do {                                                                                           \
    int _tok = my_start + (t) * BLOCK_N + lane_id;                                               \
    if (lane_id < BLOCK_N) {                                                                     \
      bool _valid = _tok < my_end;                                                               \
      int _idx = _valid ? static_cast<int>(kv_indices[_tok]) : 0;                                \
      s_kds[warp_id][(buf)][lane_id] =                                                           \
          _valid ? __bfloat162float(K_dscale[_idx * stride_kds_pool + kv_head]) : 0.0f;          \
      s_vds[warp_id][(buf)][lane_id] =                                                           \
          _valid ? __bfloat162float(V_dscale[_idx * stride_vds_pool + kv_head]) : 0.0f;          \
      if (_valid) {                                                                              \
        const uint4* _ksrc = reinterpret_cast<const uint4*>(                                     \
            K_packed + _idx * stride_kp_pool + kv_head * stride_kp_head);                        \
        const uint4* _vsrc = reinterpret_cast<const uint4*>(                                     \
            V_packed + _idx * stride_vp_pool + kv_head * stride_vp_head);                        \
        _Pragma("unroll") for (int _j = 0; _j < PACKED_VEC; _j++) {                              \
          __pipeline_memcpy_async(&s_K[warp_id][(buf)][lane_id][_j], _ksrc + _j, 16);            \
          __pipeline_memcpy_async(&s_V[warp_id][(buf)][lane_id][_j], _vsrc + _j, 16);            \
        }                                                                                        \
      }                                                                                          \
    }                                                                                            \
  } while (0)

  // prologue
  TQ4_LOAD_TILE(0, 0);
  __pipeline_commit();

  for (int t = 0; t < num_tiles; t++) {
    int buf = t & 1;
    if (t + 1 < num_tiles) {
      TQ4_LOAD_TILE(t + 1, (t + 1) & 1);
      __pipeline_commit();
    }
    __pipeline_wait_prior((t + 1 < num_tiles) ? 1 : 0);
    __syncwarp();

    const int n_valid = min(BLOCK_N, my_end - (my_start + t * BLOCK_N));
    bool valid = lane_id < n_valid;

    // Phase 1: QK from smem K tile.
    float qk[QH_TILE];
#pragma unroll
    for (int h = 0; h < QH_TILE; h++) qk[h] = 0.0f;
    if (valid) {
#pragma unroll
      for (int j = 0; j < PACKED_VEC; j++) {
        uint4 kw = s_K[warp_id][buf][lane_id][j];
        uint32_t ws[4] = {kw.x, kw.y, kw.z, kw.w};
        __nv_bfloat162 acc2[QH_TILE];
#pragma unroll
        for (int h = 0; h < QH_TILE; h++) acc2[h] = __floats2bfloat162_rn(0.0f, 0.0f);
#pragma unroll
        for (int w = 0; w < 4; w++) {
          uint32_t word = ws[w];
#pragma unroll
          for (int bb = 0; bb < 4; bb++) {
            int p = j * 16 + w * 4 + bb;
            uint8_t kb = (word >> (bb * 8)) & 0xFFu;
            float k_e = fmaf(static_cast<float>(kb & 0x0F), k_step, k_c0);
            float k_o = fmaf(static_cast<float>((kb >> 4) & 0x0F), k_step, k_c0);
            __nv_bfloat162 kpair = __floats2bfloat162_rn(k_e, k_o);
#pragma unroll
            for (int h = 0; h < QH_TILE; h++)
              acc2[h] = __hfma2(s_q_pair[h][p], kpair, acc2[h]);
          }
        }
#pragma unroll
        for (int h = 0; h < QH_TILE; h++) {
          float2 f = __bfloat1622float2(acc2[h]);
          qk[h] += f.x + f.y;
        }
      }
      float scale = s_kds[warp_id][buf][lane_id] * sm_scale;
#pragma unroll
      for (int h = 0; h < QH_TILE; h++) qk[h] *= scale;
    }

    // Phase 2: per-q-head online softmax.
    float vds = s_vds[warp_id][buf][lane_id];
#pragma unroll
    for (int h = 0; h < QH_TILE; h++) {
      float q_h = valid ? qk[h] : -FLT_MAX;
      float tile_max = warp_reduce_max(q_h);
      float old_max = e_max[h];
      e_max[h] = fmaxf(old_max, tile_max);
      float corr = __expf(old_max - e_max[h]);
      float pe = __expf(q_h - e_max[h]);
      if (lane_id >= n_valid) pe = 0.0f;
      float psum = warp_reduce_sum(pe);
#pragma unroll
      for (int i = 0; i < PP_PER_LANE; i++) {
        acc_even[h][i] *= corr;
        acc_odd[h][i] *= corr;
      }
      e_sum[h] = e_sum[h] * corr + psum;
      s_p[warp_id][h][lane_id] = (lane_id < n_valid) ? pe * vds : 0.0f;
    }
    __syncwarp();

    // Phase 3: V accum from smem V tile (lane->dim). bf16-packed (even,odd) dims via
    // hfma2; accumulate this tile in bf16 then flush to the fp32 running acc (bounds
    // the bf16-accumulate error to a 32-token tile).
    __nv_bfloat162 vacc2[QH_TILE][PP_PER_LANE];
#pragma unroll
    for (int h = 0; h < QH_TILE; h++)
#pragma unroll
      for (int i = 0; i < PP_PER_LANE; i++) vacc2[h][i] = __floats2bfloat162_rn(0.0f, 0.0f);
    for (int n = 0; n < n_valid; n++) {
      const uint32_t* v32 = reinterpret_cast<const uint32_t*>(&s_V[warp_id][buf][n][0]);
      uint32_t vword = v32[lane_id];
      __nv_bfloat162 ppair[QH_TILE];
#pragma unroll
      for (int h = 0; h < QH_TILE; h++)
        ppair[h] = __bfloat162bfloat162(__float2bfloat16(s_p[warp_id][h][n]));
#pragma unroll
      for (int i = 0; i < PP_PER_LANE; i++) {
        uint8_t vb = (vword >> (i * 8)) & 0xFFu;
        float v_e = fmaf(static_cast<float>(vb & 0x0F), v_step, v_c0);
        float v_o = fmaf(static_cast<float>((vb >> 4) & 0x0F), v_step, v_c0);
        __nv_bfloat162 vpair = __floats2bfloat162_rn(v_e, v_o);
#pragma unroll
        for (int h = 0; h < QH_TILE; h++)
          vacc2[h][i] = __hfma2(ppair[h], vpair, vacc2[h][i]);
      }
    }
#pragma unroll
    for (int h = 0; h < QH_TILE; h++)
#pragma unroll
      for (int i = 0; i < PP_PER_LANE; i++) {
        float2 f = __bfloat1622float2(vacc2[h][i]);
        acc_even[h][i] += f.x;
        acc_odd[h][i] += f.y;
      }
    __syncwarp();
  }

  // Write normalized per-split output + lse for each active q-head.
  for (int h = 0; h < qh_count; h++) {
    int qh = qh_base + h;
    float inv_sum = (e_sum[h] > 0.0f) ? (1.0f / e_sum[h]) : 0.0f;
    int out_base = batch_id * stride_att_batch + qh * stride_att_head + split_id * stride_att_split;
#pragma unroll
    for (int i = 0; i < PP_PER_LANE; i++) {
      int pp = lane_id * PP_PER_LANE + i;
      att_out[out_base + 2 * pp] = acc_even[h][i] * inv_sum;
      att_out[out_base + 2 * pp + 1] = acc_odd[h][i] * inv_sum;
    }
    if (lane_id == 0) {
      att_lse[batch_id * H_Q * max_kv_splits + qh * max_kv_splits + split_id] =
          e_max[h] + logf(fmaxf(e_sum[h], 1e-10f));
    }
  }
}
#undef TQ4_LOAD_TILE

// -- host launcher (TVM-FFI) -----------------------------------------------
void tq4_decode_stage1_launch(
    tvm::ffi::TensorView Q, tvm::ffi::TensorView K_packed, tvm::ffi::TensorView V_packed,
    tvm::ffi::TensorView K_dscale, tvm::ffi::TensorView V_dscale,
    tvm::ffi::TensorView kv_indptr, tvm::ffi::TensorView kv_indices,
    tvm::ffi::TensorView num_kv_splits,
    tvm::ffi::TensorView att_out, tvm::ffi::TensorView att_lse,
    tvm::ffi::TensorView k_centroids, tvm::ffi::TensorView v_centroids,
    double sm_scale, int64_t max_kv_splits) {
  using namespace host;
  const DLDevice device = Q.device();

  const int batch = static_cast<int>(Q.shape()[0]);
  const int h_q = static_cast<int>(Q.shape()[1]);
  const int h_kv = static_cast<int>(K_packed.shape()[1]);
  const int kv_group = h_q / h_kv;
  const int chunks_per_kv = (kv_group + QH_TILE - 1) / QH_TILE;
  const int max_splits = static_cast<int>(max_kv_splits);

  dim3 grid(batch, h_kv * chunks_per_kv, (max_splits + BLOCK_W - 1) / BLOCK_W);
  dim3 block(BLOCK_SIZE);

  LaunchKernel(grid, block, device)(
      tq4_decode_stage1_v2,
      static_cast<const __nv_bfloat16*>(Q.data_ptr()),
      static_cast<const uint8_t*>(K_packed.data_ptr()),
      static_cast<const uint8_t*>(V_packed.data_ptr()),
      static_cast<const __nv_bfloat16*>(K_dscale.data_ptr()),
      static_cast<const __nv_bfloat16*>(V_dscale.data_ptr()),
      static_cast<const int32_t*>(kv_indptr.data_ptr()),
      static_cast<const int64_t*>(kv_indices.data_ptr()),
      static_cast<const int32_t*>(num_kv_splits.data_ptr()),
      static_cast<float*>(att_out.data_ptr()),
      static_cast<float*>(att_lse.data_ptr()),
      static_cast<const float*>(k_centroids.data_ptr()),
      static_cast<const float*>(v_centroids.data_ptr()),
      static_cast<float>(sm_scale),
      h_q, h_kv, max_splits,
      static_cast<int>(Q.stride(0)), static_cast<int>(Q.stride(1)),
      static_cast<int>(K_packed.stride(0)), static_cast<int>(K_packed.stride(1)),
      static_cast<int>(V_packed.stride(0)), static_cast<int>(V_packed.stride(1)),
      static_cast<int>(K_dscale.stride(0)), static_cast<int>(V_dscale.stride(0)),
      static_cast<int>(att_out.stride(0)), static_cast<int>(att_out.stride(1)),
      static_cast<int>(att_out.stride(2)),
      kv_group);
}

// -- tensor-core (WMMA bf16) stage1 variant -- EXPERIMENT, SLOWER, gated off --
// Per warp = one (kv_head, split), all q-heads of the group (M padded to 16).
// QK + PV via WMMA m16n16k16 on 4-bit->bf16 dequanted full K/V tiles; O in smem
// with online softmax. Env-gated (NETRA_TQ4_DECODE_MMA=1).
//
// RESULT (H200, bs1/128k/hd256/GQA8): ~1.3 ms/step vs the cp.async scalar
// kernel's 0.136 ms — ~10x SLOWER, and worse precision (bf16 mma, rel-err 0.061
// vs 0.004). For DECODE the matmuls are tiny (M=8), so WMMA's per-mma fragment
// staging + smem-accumulate + syncs + single-warp serialization dominate the
// tiny mma compute. Tensor cores are NOT the win for this shape without an
// FA3-class warp-specialized/async rewrite. Kept for the record; DEFAULT is the
// cp.async scalar kernel.
namespace wmma = nvcuda::wmma;

__global__ void tq4_decode_stage1_mma_kernel(
    const __nv_bfloat16* __restrict__ Q,
    const uint8_t* __restrict__ K_packed,
    const uint8_t* __restrict__ V_packed,
    const __nv_bfloat16* __restrict__ K_dscale,
    const __nv_bfloat16* __restrict__ V_dscale,
    const int32_t* __restrict__ kv_indptr,
    const int64_t* __restrict__ kv_indices,
    const int32_t* __restrict__ num_kv_splits,
    float* __restrict__ att_out,
    float* __restrict__ att_lse,
    const float* __restrict__ k_centroids,
    const float* __restrict__ v_centroids,
    float sm_scale,
    int H_Q, int H_KV, int max_kv_splits,
    int stride_q_batch, int stride_q_head,
    int stride_kp_pool, int stride_kp_head,
    int stride_vp_pool, int stride_vp_head,
    int stride_kds_pool, int stride_vds_pool,
    int stride_att_batch, int stride_att_head, int stride_att_split,
    int kv_group_num) {
  constexpr int WM = 16, WN = 16, WK = 16;
  constexpr int TN = 16;                 // tokens per tile (= WN)
  constexpr int KD = HEAD_DIM / 16;      // head_dim 16-tiles (16)
  const int batch_id = blockIdx.x;
  const int kv_head = blockIdx.y;
  const int split_id = blockIdx.z;
  const int lane = threadIdx.x;          // single warp
  const int qh_base = kv_head * kv_group_num;
  const int qh_count = kv_group_num;     // <= 16

  __shared__ __nv_bfloat16 s_Q[16][HEAD_DIM];
  __shared__ float s_O[16][HEAD_DIM];
  __shared__ uint8_t s_Kp[TN][PACKED_DIM];
  __shared__ uint8_t s_Vp[TN][PACKED_DIM];
  __shared__ __nv_bfloat16 s_Kb[TN][HEAD_DIM];  // full dequanted K tile
  __shared__ __nv_bfloat16 s_Vb[TN][HEAD_DIM];  // full dequanted V tile
  __shared__ float s_S[16][16];
  __shared__ __nv_bfloat16 s_P[16][16];
  __shared__ float s_Otmp[16][16];
  __shared__ float s_emax[16], s_esum[16], s_corr[16];
  __shared__ float s_kds[TN], s_vds[TN];

  const float k_c0 = k_centroids[0];
  const float k_step = (k_centroids[15] - k_centroids[0]) * (1.0f / 15.0f);
  const float v_c0 = v_centroids[0];
  const float v_step = (v_centroids[15] - v_centroids[0]) * (1.0f / 15.0f);

  for (int i = lane; i < 16 * HEAD_DIM; i += 32) {
    int r = i / HEAD_DIM, c = i % HEAD_DIM;
    s_Q[r][c] = (r < qh_count)
        ? Q[batch_id * stride_q_batch + (qh_base + r) * stride_q_head + c]
        : __float2bfloat16(0.0f);
    s_O[r][c] = 0.0f;
  }
  if (lane < 16) { s_emax[lane] = -FLT_MAX; s_esum[lane] = 0.0f; }
  __syncwarp();

  const int kv_start = kv_indptr[batch_id];
  const int kv_end = kv_indptr[batch_id + 1];
  const int kv_len = kv_end - kv_start;
  const int n_splits = num_kv_splits[batch_id];
  const int split_len = (kv_len + n_splits - 1) / n_splits;
  const int aligned_len = ((split_len + MIN_BLOCK_KV - 1) / MIN_BLOCK_KV) * MIN_BLOCK_KV;
  const int my_start = kv_start + split_id * aligned_len;
  const int my_end = min(my_start + aligned_len, kv_end);

  if (split_id >= max_kv_splits) return;
  if (my_start >= kv_end) {
    if (lane < qh_count)
      att_lse[batch_id * H_Q * max_kv_splits + (qh_base + lane) * max_kv_splits + split_id] = -FLT_MAX;
    return;
  }

  for (int tok0 = my_start; tok0 < my_end; tok0 += TN) {
    const int n_valid = min(TN, my_end - tok0);
    if (lane < TN) {
      int tok = tok0 + lane;
      bool v = tok < my_end;
      int idx = v ? static_cast<int>(kv_indices[tok]) : 0;
      s_kds[lane] = v ? __bfloat162float(K_dscale[idx * stride_kds_pool + kv_head]) : 0.0f;
      s_vds[lane] = v ? __bfloat162float(V_dscale[idx * stride_vds_pool + kv_head]) : 0.0f;
      const uint8_t* kp = K_packed + idx * stride_kp_pool + kv_head * stride_kp_head;
      const uint8_t* vp = V_packed + idx * stride_vp_pool + kv_head * stride_vp_head;
#pragma unroll
      for (int b = 0; b < PACKED_DIM; b++) {
        s_Kp[lane][b] = v ? kp[b] : 0;
        s_Vp[lane][b] = v ? vp[b] : 0;
      }
    }
    __syncwarp();

    // dequant the FULL K and V tiles to bf16 smem once (no per-mma dequant/sync)
    for (int i = lane; i < TN * HEAD_DIM; i += 32) {
      int t = i / HEAD_DIM, hd = i % HEAD_DIM;
      uint8_t kb = s_Kp[t][hd >> 1];
      int kc = (hd & 1) ? ((kb >> 4) & 0xF) : (kb & 0xF);
      s_Kb[t][hd] = __float2bfloat16((k_c0 + kc * k_step) * s_kds[t]);
      uint8_t vb = s_Vp[t][hd >> 1];
      int vc = (hd & 1) ? ((vb >> 4) & 0xF) : (vb & 0xF);
      s_Vb[t][hd] = __float2bfloat16((v_c0 + vc * v_step) * s_vds[t]);
    }
    __syncwarp();

    // ---- QK: S = Q @ K^T over KD head_dim tiles (read full s_Kb) ----
    wmma::fragment<wmma::accumulator, WM, WN, WK, float> s_acc;
    wmma::fill_fragment(s_acc, 0.0f);
    for (int kd = 0; kd < KD; kd++) {
      wmma::fragment<wmma::matrix_a, WM, WN, WK, __nv_bfloat16, wmma::row_major> q_frag;
      wmma::fragment<wmma::matrix_b, WM, WN, WK, __nv_bfloat16, wmma::col_major> k_frag;
      wmma::load_matrix_sync(q_frag, &s_Q[0][kd * 16], HEAD_DIM);
      wmma::load_matrix_sync(k_frag, &s_Kb[0][kd * 16], HEAD_DIM);
      wmma::mma_sync(s_acc, q_frag, k_frag, s_acc);
    }
    wmma::store_matrix_sync(&s_S[0][0], s_acc, 16, wmma::mem_row_major);
    __syncwarp();

    // ---- online softmax (lane = q-head) ----
    if (lane < qh_count) {
      int qh = lane;
      float mx = -FLT_MAX;
      for (int t = 0; t < n_valid; t++) { float s = s_S[qh][t] * sm_scale; s_S[qh][t] = s; mx = fmaxf(mx, s); }
      float old = s_emax[qh];
      float nmax = fmaxf(old, mx);
      s_emax[qh] = nmax;
      float corr = __expf(old - nmax);
      s_corr[qh] = corr;
      float sm = 0.0f;
      for (int t = 0; t < n_valid; t++) { float p = __expf(s_S[qh][t] - nmax); s_P[qh][t] = __float2bfloat16(p); sm += p; }
      for (int t = n_valid; t < 16; t++) s_P[qh][t] = __float2bfloat16(0.0f);
      s_esum[qh] = s_esum[qh] * corr + sm;
    } else if (lane < 16) {
      s_corr[lane] = 1.0f;
      for (int t = 0; t < 16; t++) s_P[lane][t] = __float2bfloat16(0.0f);
    }
    __syncwarp();
    // rescale s_O rows by their corr (all lanes cooperate)
    for (int i = lane; i < 16 * HEAD_DIM; i += 32) s_O[i / HEAD_DIM][i % HEAD_DIM] *= s_corr[i / HEAD_DIM];
    __syncwarp();

    // ---- PV: O[*][nd] += P @ V over KD head_dim tiles (read full s_Vb) ----
    for (int nd = 0; nd < KD; nd++) {
      wmma::fragment<wmma::matrix_a, WM, WN, WK, __nv_bfloat16, wmma::row_major> p_frag;
      wmma::fragment<wmma::matrix_b, WM, WN, WK, __nv_bfloat16, wmma::row_major> v_frag;
      wmma::fragment<wmma::accumulator, WM, WN, WK, float> o_acc;
      wmma::fill_fragment(o_acc, 0.0f);
      wmma::load_matrix_sync(p_frag, &s_P[0][0], 16);
      wmma::load_matrix_sync(v_frag, &s_Vb[0][nd * 16], HEAD_DIM);
      wmma::mma_sync(o_acc, p_frag, v_frag, o_acc);
      wmma::store_matrix_sync(&s_Otmp[0][0], o_acc, 16, wmma::mem_row_major);
      __syncwarp();
      for (int i = lane; i < 16 * 16; i += 32) { int r = i / 16, h = i % 16; s_O[r][nd * 16 + h] += s_Otmp[r][h]; }
      __syncwarp();
    }
  }

  // ---- write normalized per-split output + lse ----
  for (int qh = 0; qh < qh_count; qh++) {
    float inv = (s_esum[qh] > 0.0f) ? (1.0f / s_esum[qh]) : 0.0f;
    int out_base = batch_id * stride_att_batch + (qh_base + qh) * stride_att_head + split_id * stride_att_split;
    for (int d = lane; d < HEAD_DIM; d += 32) att_out[out_base + d] = s_O[qh][d] * inv;
    if (lane == 0)
      att_lse[batch_id * H_Q * max_kv_splits + (qh_base + qh) * max_kv_splits + split_id] =
          s_emax[qh] + logf(fmaxf(s_esum[qh], 1e-10f));
  }
}

void tq4_decode_stage1_mma_launch(
    tvm::ffi::TensorView Q, tvm::ffi::TensorView K_packed, tvm::ffi::TensorView V_packed,
    tvm::ffi::TensorView K_dscale, tvm::ffi::TensorView V_dscale,
    tvm::ffi::TensorView kv_indptr, tvm::ffi::TensorView kv_indices,
    tvm::ffi::TensorView num_kv_splits,
    tvm::ffi::TensorView att_out, tvm::ffi::TensorView att_lse,
    tvm::ffi::TensorView k_centroids, tvm::ffi::TensorView v_centroids,
    double sm_scale, int64_t max_kv_splits) {
  using namespace host;
  const DLDevice device = Q.device();
  const int batch = static_cast<int>(Q.shape()[0]);
  const int h_q = static_cast<int>(Q.shape()[1]);
  const int h_kv = static_cast<int>(K_packed.shape()[1]);
  const int kv_group = h_q / h_kv;
  const int max_splits = static_cast<int>(max_kv_splits);
  dim3 grid(batch, h_kv, max_splits);
  dim3 block(32);
  LaunchKernel(grid, block, device)(
      tq4_decode_stage1_mma_kernel,
      static_cast<const __nv_bfloat16*>(Q.data_ptr()),
      static_cast<const uint8_t*>(K_packed.data_ptr()),
      static_cast<const uint8_t*>(V_packed.data_ptr()),
      static_cast<const __nv_bfloat16*>(K_dscale.data_ptr()),
      static_cast<const __nv_bfloat16*>(V_dscale.data_ptr()),
      static_cast<const int32_t*>(kv_indptr.data_ptr()),
      static_cast<const int64_t*>(kv_indices.data_ptr()),
      static_cast<const int32_t*>(num_kv_splits.data_ptr()),
      static_cast<float*>(att_out.data_ptr()),
      static_cast<float*>(att_lse.data_ptr()),
      static_cast<const float*>(k_centroids.data_ptr()),
      static_cast<const float*>(v_centroids.data_ptr()),
      static_cast<float>(sm_scale),
      h_q, h_kv, max_splits,
      static_cast<int>(Q.stride(0)), static_cast<int>(Q.stride(1)),
      static_cast<int>(K_packed.stride(0)), static_cast<int>(K_packed.stride(1)),
      static_cast<int>(V_packed.stride(0)), static_cast<int>(V_packed.stride(1)),
      static_cast<int>(K_dscale.stride(0)), static_cast<int>(V_dscale.stride(0)),
      static_cast<int>(att_out.stride(0)), static_cast<int>(att_out.stride(1)),
      static_cast<int>(att_out.stride(2)),
      kv_group);
}

// -- stage2: flash-decode split reduce (replaces the slow Triton reduce) ----
// One block per (batch, q_head); combine per-split normalized outputs + lse via
// softmax(lse) weights: out[d] = sum_s att_out[s][d] * softmax_s(lse[s]).
__global__ void tq4_decode_stage2_kernel(
    const float* __restrict__ att_out,
    const float* __restrict__ att_lse,
    const int32_t* __restrict__ num_kv_splits,
    __nv_bfloat16* __restrict__ o,
    int max_splits, int head_dim,
    int stride_ao_b, int stride_ao_h, int stride_ao_s,
    int stride_lse_b, int stride_lse_h,
    int stride_o_b, int stride_o_h) {
  const int b = blockIdx.x;
  const int qh = blockIdx.y;
  // Reduce only over splits this sequence actually launched. Reading the full
  // padded capacity is the CUDA-graph bug: the scratch is sized to max capacity
  // and persists across replays, but stage1 only initialized [0, num_kv_splits[b]),
  // and even inside that range MIN_BLOCK_KV alignment leaves EMPTY splits whose
  // att_out stage1 never wrote (stale). Bound by n, and skip empties via the
  // exact sentinel stage1 stores: lse == -FLT_MAX (a finite value, so a > -inf
  // test does NOT catch it).
  int n = num_kv_splits[b];
  if (n > max_splits) n = max_splits;

  __shared__ float s_lse[2048];
  for (int s = threadIdx.x; s < n; s += blockDim.x)
    s_lse[s] = att_lse[b * stride_lse_b + qh * stride_lse_h + s];
  __syncthreads();

  float M = -FLT_MAX;
  for (int s = 0; s < n; s++) M = fmaxf(M, s_lse[s]);

  if (M == -FLT_MAX) {  // all splits empty -> emit zeros, never divide
    for (int d = threadIdx.x; d < head_dim; d += blockDim.x)
      o[b * stride_o_b + qh * stride_o_h + d] = __float2bfloat16(0.0f);
    return;
  }

  for (int d = threadIdx.x; d < head_dim; d += blockDim.x) {
    const float* ao = att_out + b * stride_ao_b + qh * stride_ao_h + d;
    float denom = 0.0f, acc = 0.0f;
    for (int s = 0; s < n; s++) {
      float lse = s_lse[s];
      if (lse == -FLT_MAX) continue;  // empty split: att_out unwritten, skip
      float w = __expf(lse - M);
      denom += w;
      acc += w * ao[s * stride_ao_s];
    }
    o[b * stride_o_b + qh * stride_o_h + d] = __float2bfloat16(acc / fmaxf(denom, 1e-20f));
  }
}

void tq4_decode_stage2_launch(
    tvm::ffi::TensorView att_out, tvm::ffi::TensorView att_lse,
    tvm::ffi::TensorView num_kv_splits, tvm::ffi::TensorView o) {
  using namespace host;
  const DLDevice device = att_out.device();
  // Derive batch/heads from o (sized to the real decode bs), NOT att_out: under
  // CUDA graph att_out is allocated at max_num_tokens (>= bs), so using its
  // shape[0] launches extra blocks that write o out of bounds and corrupt
  // adjacent graph-pool tensors. The stock reduce derives batch from q for the
  // same reason.
  const int bs = static_cast<int>(o.shape()[0]);
  const int h_q = static_cast<int>(o.shape()[1]);
  const int head_dim = static_cast<int>(o.shape()[2]);
  const int max_splits = static_cast<int>(att_out.shape()[2]);
  const int threads = head_dim < 256 ? head_dim : 256;
  dim3 grid(bs, h_q);
  dim3 block(threads);
  LaunchKernel(grid, block, device)(
      tq4_decode_stage2_kernel,
      static_cast<const float*>(att_out.data_ptr()),
      static_cast<const float*>(att_lse.data_ptr()),
      static_cast<const int32_t*>(num_kv_splits.data_ptr()),
      static_cast<__nv_bfloat16*>(o.data_ptr()),
      max_splits, head_dim,
      static_cast<int>(att_out.stride(0)), static_cast<int>(att_out.stride(1)),
      static_cast<int>(att_out.stride(2)),
      static_cast<int>(att_lse.stride(0)), static_cast<int>(att_lse.stride(1)),
      static_cast<int>(o.stride(0)), static_cast<int>(o.stride(1)));
}

}  // namespace
