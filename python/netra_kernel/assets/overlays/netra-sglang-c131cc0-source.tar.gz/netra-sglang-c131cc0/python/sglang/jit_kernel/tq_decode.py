from __future__ import annotations

import os
from typing import TYPE_CHECKING

import torch

from sglang.jit_kernel.utils import cache_once, load_jit, override_jit_cuda_arch

# Stage1 variant is selected at CALL time (so tests / /cache benches can toggle by
# env without re-importing): NETRA_TQ4_DECODE_WGMMA=1 -> FA3-class Hopper WGMMA
# tensor-core stage1 (sm_90a); NETRA_TQ4_DECODE_MMA=1 -> experimental WMMA stage1
# (slower, kept for the record); else the cp.async scalar stage1 (default).

if TYPE_CHECKING:
    from tvm_ffi import Module


@cache_once
def _jit_tq_decode_module() -> "Module":
    return load_jit(
        "tq_decode",
        cuda_files=["tq_decode/tq4_decode_stage1.cuh"],
        cuda_wrappers=[
            ("tq4_decode_stage1", "tq4_decode_stage1_launch"),
            ("tq4_decode_stage1_mma", "tq4_decode_stage1_mma_launch"),
            ("tq4_decode_stage2", "tq4_decode_stage2_launch"),
        ],
        extra_cuda_cflags=["--use_fast_math"],
    )


@cache_once
def _jit_tq_decode_wgmma_module() -> "Module":
    """Separate JIT module for the WGMMA stage1: it needs sm_90a (wgmma won't
    assemble under plain sm_90) + cutlass (cute GMMA descriptors/atoms). Isolated
    so the proven cp.async scalar / stage2 path stays on sm_90 with no cutlass dep.
    """
    with override_jit_cuda_arch(9, 0, "a"):
        return load_jit(
            "tq_decode_wgmma",
            cuda_files=["tq_decode/tq4_decode_stage1_wgmma.cuh"],
            cuda_wrappers=[
                (
                    "tq4_decode_stage1_wgmma",
                    "tq4_wgmma::tq4_decode_stage1_wgmma_launch",
                ),
                (
                    "tq4_decode_stage1_wgmma_fp8",
                    "tq4_wgmma::tq4_decode_stage1_wgmma_fp8_launch",
                ),
            ],
            extra_cuda_cflags=["--use_fast_math"],
            extra_dependencies=["cutlass"],
        )


def tq4_decode_stage1(
    q,
    k_packed,
    v_packed,
    k_dscale,
    v_dscale,
    kv_indptr,
    kv_indices,
    num_kv_splits,
    att_out,
    att_lse,
    k_centroids,
    v_centroids,
    sm_scale,
    max_kv_splits,
) -> None:
    """CUDA-native TQ4 decode stage1. Writes normalized per-split att_out + att_lse.

    Arg order matches the C++ host launcher exactly. kv_indices MUST be int64
    (the kernel casts int64 -> int); kv_indptr/num_kv_splits are int32.
    """
    if not q.is_cuda:
        raise RuntimeError("tq4_decode_stage1 only supports CUDA tensors")
    assert kv_indices.dtype == torch.int64, (
        f"kv_indices must be int64, got {kv_indices.dtype}"
    )
    if os.getenv("NETRA_TQ4_DECODE_WGMMA_FP8", "0") == "1":
        fn = _jit_tq_decode_wgmma_module().tq4_decode_stage1_wgmma_fp8
    elif os.getenv("NETRA_TQ4_DECODE_WGMMA", "0") == "1":
        fn = _jit_tq_decode_wgmma_module().tq4_decode_stage1_wgmma
    elif os.getenv("NETRA_TQ4_DECODE_MMA", "0") == "1":
        fn = _jit_tq_decode_module().tq4_decode_stage1_mma
    else:
        fn = _jit_tq_decode_module().tq4_decode_stage1
    fn(
        q,
        k_packed,
        v_packed,
        k_dscale,
        v_dscale,
        kv_indptr,
        kv_indices,
        num_kv_splits,
        att_out,
        att_lse,
        k_centroids,
        v_centroids,
        float(sm_scale),
        int(max_kv_splits),
    )


def tq4_decode_stage2(att_out, att_lse, num_kv_splits, o) -> None:
    """CUDA-native flash-decode stage2 reduce: combine per-split normalized
    att_out via softmax(att_lse) weights into o (bf16). Reduces over exactly
    num_kv_splits[b] splits (CUDA-graph-safe: the scratch tail beyond the
    sequence's split count is uninitialized/stale). Replaces the Triton
    _decode_softmax_reducev_fwd for the no-sink TQ4 decode path.

    att_out:       [bs, q_heads, max_splits, head_dim] float32
    att_lse:       [bs, q_heads, max_splits] float32
    num_kv_splits: [bs] int32
    o:             [bs, q_heads, head_dim] bf16 (output)
    """
    mod = _jit_tq_decode_module()
    mod.tq4_decode_stage2(att_out, att_lse, num_kv_splits, o)


def warmup(max_splits: int = 512) -> None:
    """Force-compile BOTH the CUDA stage1 and the Triton stage2 reduce so neither
    JIT-compiles during CUDA-graph capture (mirrors vLLM #42215). MUST be warmed
    at the real `max_splits` (= server --triton-attention-num-kv-splits): the
    Triton reduce compiles per SPLITS_PAD signature, so warming a different split
    count leaves the real one to compile inside capture -> garbage on replay.
    Call once at backend init when the CUDA decode kernel is selected.
    """
    import math

    dev = torch.device("cuda")
    bs, hq, hkv, hd, pk = 1, 16, 2, 256, 128
    splits = max(int(max_splits), 1)
    ntok = max(splits, 64)
    q = torch.zeros(bs, hq, hd, dtype=torch.bfloat16, device=dev)
    kp = torch.zeros(ntok, hkv, pk, dtype=torch.uint8, device=dev)
    vp = torch.zeros(ntok, hkv, pk, dtype=torch.uint8, device=dev)
    kds = torch.ones(ntok, hkv, dtype=torch.bfloat16, device=dev)
    vds = torch.ones(ntok, hkv, dtype=torch.bfloat16, device=dev)
    kc = torch.zeros(16, dtype=torch.float32, device=dev)
    vc = torch.zeros(16, dtype=torch.float32, device=dev)
    att_out = torch.zeros(bs, hq, splits, hd, dtype=torch.float32, device=dev)
    att_lse = torch.zeros(bs, hq, splits, dtype=torch.float32, device=dev)
    kv_indptr = torch.tensor([0, ntok], dtype=torch.int32, device=dev)
    kv_indices = torch.arange(ntok, dtype=torch.int64, device=dev)
    num_kv_splits = torch.full((bs,), splits, dtype=torch.int32, device=dev)
    o = torch.zeros(bs, hq, hd, dtype=torch.bfloat16, device=dev)
    tq4_decode_stage1(
        q, kp, vp, kds, vds, kv_indptr, kv_indices, num_kv_splits,
        att_out, att_lse, kc, vc, 1.0 / math.sqrt(hd), splits,
    )
    tq4_decode_stage2(att_out, att_lse, num_kv_splits, o)
    torch.cuda.synchronize()
