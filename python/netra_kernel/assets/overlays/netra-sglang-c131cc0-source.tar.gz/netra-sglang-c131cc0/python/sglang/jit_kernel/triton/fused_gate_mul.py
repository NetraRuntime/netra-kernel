from __future__ import annotations

import torch
import triton
import triton.language as tl

from sglang.srt.utils.custom_op import register_custom_op

# =============================================================================
# Fused attention output gate: out = x * sigmoid(gate), one pass.
#
# qwen3_5's attn_output_gate runs this as TWO eager kernels with an extra
# full-tensor round-trip (sigmoid: strided gate read -> contiguous write;
# mul: read both -> write), together ~4% of A100 decode GPU time (sigmoid
# 1.2% + MulFunctor 2.9%, run 20260726_111114). This kernel reads the strided
# gate view straight out of the packed qkv projection (per-(t,h) rows of D
# contiguous elements) and multiplies in fp32, writing the gated output once:
# 5 memory passes -> 3. Registered as a custom op so the piecewise-compiled
# attention region can call it without a graph break.
# =============================================================================


@triton.jit
def _fused_sigmoid_gate_mul_kernel(
    x_ptr,
    g_ptr,
    out_ptr,
    T,
    g_stride_t,
    g_stride_h,
    H: tl.constexpr,
    D: tl.constexpr,
    BLOCK_T: tl.constexpr,
):
    pid_t = tl.program_id(0)
    h = tl.program_id(1)
    t = pid_t * BLOCK_T + tl.arange(0, BLOCK_T)
    mask = t < T
    d = tl.arange(0, D)
    x = tl.load(
        x_ptr + t[:, None] * (H * D) + h * D + d[None, :],
        mask=mask[:, None],
        other=0.0,
    ).to(tl.float32)
    g = tl.load(
        g_ptr + t[:, None] * g_stride_t + h * g_stride_h + d[None, :],
        mask=mask[:, None],
        other=0.0,
    ).to(tl.float32)
    y = x * tl.sigmoid(g)
    tl.store(
        out_ptr + t[:, None] * (H * D) + h * D + d[None, :],
        y.to(out_ptr.dtype.element_ty),
        mask=mask[:, None],
    )


def fake_fused_sigmoid_gate_mul(
    x: torch.Tensor, gate: torch.Tensor
) -> torch.Tensor:
    return torch.empty_like(x)


@register_custom_op(fake_impl=fake_fused_sigmoid_gate_mul)
def fused_sigmoid_gate_mul(x: torch.Tensor, gate: torch.Tensor) -> torch.Tensor:
    """x: contiguous [T, H*D] (or any 2D-viewable contiguous). gate: [T, H, D]
    view whose last dim is contiguous (T/H arbitrarily strided). Returns
    x * sigmoid(gate) flattened to x's shape."""
    t, h, d = gate.shape
    assert gate.stride(-1) == 1, "gate head dim must be contiguous"
    assert x.is_contiguous() and x.numel() == t * h * d
    out = torch.empty_like(x)
    BLOCK_T = 32
    grid = (triton.cdiv(t, BLOCK_T), h)
    _fused_sigmoid_gate_mul_kernel[grid](
        x,
        gate,
        out,
        t,
        gate.stride(0),
        gate.stride(1),
        H=h,
        D=d,
        BLOCK_T=BLOCK_T,
        num_warps=4,
        num_stages=2,
    )
    return out
