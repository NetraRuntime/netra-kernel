"""Microbenchmark + ncu harness for the TQ4 decode attention stage1 CUDA kernel.

Builds realistic packed-KV decode inputs at our serving geometry (Qwen3.6 hybrid:
head_dim=256, n_kv_heads=2, q_heads=32) and times:
  - cuda_stage1: the CUDA stage1 kernel under optimization (tq4_decode_stage1)
  - cuda_full  : CUDA stage1 + Triton stage2 reduce (tq_cuda_decode_attention_fwd)
  - triton_full: the all-Triton fused decode (tq_decode_attention_fwd) -- parity ref

Two modes:
  bench  : sweep (batch x kv_len) at a chosen split policy, print a table.
  single : one config, N launches (for `ncu -k tq4_decode_stage1_v2 -s W -c 1`).

The KV pool is built ONCE at the max size needed and sliced per config, so a sweep
doesn't re-pack millions of tokens. num_kv_splits policy is selectable:
  --splits-mode static    -> num_kv_splits[b] = --splits (the "tuned 512" baseline)
  --splits-mode heuristic -> SGLang get_num_kv_splits_triton (per-seq, SM-aware)

Usage (inside the sgl container, repo at /workspace/netra-server):
  python -m sglang.jit_kernel.benchmark.bench_tq_decode --mode bench \
      --batches 1,8,32 --kv-lens 4096,16384,65536 --splits 512
  ncu --set full -k tq4_decode_stage1_v2 -s 8 -c 1 \
      python -m sglang.jit_kernel.benchmark.bench_tq_decode --mode single \
      --batch 1 --kv-len 131072 --splits 512 --iters 10
"""

from __future__ import annotations

import argparse
import math

import torch
import triton

CUDA = torch.cuda.is_available()


# --- input construction --------------------------------------------------------


def _make_cfg(head_dim, device="cuda"):
    from sglang.srt.layers.quantization.kv_turboquant import TurboQuantConfig

    return TurboQuantConfig(
        bit_width=4, head_dim=head_dim, device=device, uniform=True
    )


def _pack_pool(K_raw, V_raw, cfg, device="cuda"):
    """Pack a [N, n_kv_heads, head_dim] bf16 pool into TQ4 scratch (identity slots)."""
    from sglang.srt.layers.attention.triton_ops.turboquant_quantize import (
        fused_turboquant_quantize_and_store_kv,
    )

    n, heads, dim = K_raw.shape
    pk = dim // 2
    k_buf = torch.zeros(n, heads, pk, dtype=torch.uint8, device=device)
    v_buf = torch.zeros(n, heads, pk, dtype=torch.uint8, device=device)
    k_ds = torch.zeros(n, heads, dtype=torch.bfloat16, device=device)
    v_ds = torch.zeros(n, heads, dtype=torch.bfloat16, device=device)
    loc = torch.arange(n, dtype=torch.int64, device=device)
    fused_turboquant_quantize_and_store_kv(
        K_raw, V_raw, cfg.signs1, cfg.signs2,
        cfg.k_centroids, cfg.k_boundaries, cfg.k_bit_width,
        cfg.v_centroids, cfg.v_boundaries, cfg.v_bit_width,
        k_buf, k_ds, v_buf, v_ds, loc,
    )
    return k_buf, v_buf, k_ds, v_ds


def _heuristic_splits(seq_lens, num_head, num_kv_head, max_kv_splits, sm_count):
    """SGLang get_num_kv_splits_triton, called standalone for the bench."""
    from sglang.srt.layers.attention.triton_backend import get_num_kv_splits_triton

    bs = seq_lens.shape[0]
    out = torch.empty(bs, dtype=torch.int32, device=seq_lens.device)
    SCHEDULE_SEQ = 256 if bs < 256 else triton.next_power_of_2(bs)
    get_num_kv_splits_triton[(1,)](
        out, seq_lens, bs, 1, num_head, num_kv_head,
        max_kv_splits, sm_count, MAX_NUM_SEQ=SCHEDULE_SEQ,
    )
    return out


class Inputs:
    """Holds everything needed to launch one decode config, sliced from a pool."""

    def __init__(self, pool, batch, kv_len, q_heads, kv_heads, head_dim,
                 num_kv_splits, max_kv_splits, cfg, device="cuda"):
        k_buf, v_buf, k_ds, v_ds = pool
        self.cfg = cfg
        self.head_dim = head_dim
        self.max_kv_splits = max_kv_splits
        self.sm_scale = 1.0 / math.sqrt(head_dim)
        self.k_buf, self.v_buf, self.k_ds, self.v_ds = k_buf, v_buf, k_ds, v_ds

        # distinct contiguous slabs per batch row
        total = batch * kv_len
        assert total <= k_buf.shape[0], f"pool too small: need {total}, have {k_buf.shape[0]}"
        self.kv_indptr = torch.arange(
            0, (batch + 1) * kv_len, kv_len, dtype=torch.int32, device=device
        )
        self.kv_indices = torch.arange(total, dtype=torch.int64, device=device)
        self.num_kv_splits = num_kv_splits

        Q_raw = torch.randn(batch, q_heads, head_dim, device=device, dtype=torch.bfloat16)
        self.Q_rot = cfg.rotate_query(Q_raw).to(torch.bfloat16)
        self.o = torch.zeros(batch, q_heads, head_dim, device=device, dtype=torch.bfloat16)
        self.att_logits = torch.zeros(
            batch, q_heads, max_kv_splits, head_dim, device=device, dtype=torch.float32
        )
        self.att_lse = torch.zeros(
            batch, q_heads, max_kv_splits, device=device, dtype=torch.float32
        )

    def cuda_stage1(self):
        from sglang.jit_kernel.tq_decode import tq4_decode_stage1

        tq4_decode_stage1(
            self.Q_rot, self.k_buf, self.v_buf, self.k_ds, self.v_ds,
            self.kv_indptr, self.kv_indices, self.num_kv_splits,
            self.att_logits, self.att_lse, self.cfg.k_centroids, self.cfg.v_centroids,
            self.sm_scale, self.max_kv_splits,
        )

    def cuda_full(self):
        from sglang.srt.layers.attention.triton_ops.turboquant_decode_attention import (
            tq_cuda_decode_attention_fwd,
        )

        tq_cuda_decode_attention_fwd(
            self.Q_rot, self.k_buf, self.v_buf, self.k_ds, self.v_ds,
            self.cfg.k_centroids, self.cfg.v_centroids, self.o,
            self.kv_indptr, self.kv_indices, self.att_logits, self.att_lse,
            self.num_kv_splits, self.max_kv_splits, self.sm_scale,
            k_bit_width=4, v_bit_width=4, uniform=True,
        )

    def triton_full(self):
        from sglang.srt.layers.attention.triton_ops.turboquant_decode_attention import (
            tq_decode_attention_fwd,
        )

        tq_decode_attention_fwd(
            self.Q_rot, self.k_buf, self.v_buf, self.k_ds, self.v_ds,
            self.cfg.k_centroids, self.cfg.v_centroids, self.o,
            self.kv_indptr, self.kv_indices, self.att_logits, self.att_lse,
            self.num_kv_splits, self.max_kv_splits, self.sm_scale,
            k_bit_width=4, v_bit_width=4, uniform=True,
        )


# --- timing --------------------------------------------------------------------


def time_us(fn, iters=50, warmup=10):
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    s = torch.cuda.Event(enable_timing=True)
    e = torch.cuda.Event(enable_timing=True)
    times = []
    for _ in range(iters):
        s.record()
        fn()
        e.record()
        torch.cuda.synchronize()
        times.append(s.elapsed_time(e) * 1e3)  # ms -> us
    times.sort()
    return times[len(times) // 2]  # median


# --- main ----------------------------------------------------------------------


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["bench", "single"], default="bench")
    ap.add_argument("--batches", default="1,8,32")
    ap.add_argument("--kv-lens", default="4096,16384,65536")
    ap.add_argument("--batch", type=int, default=1)       # single mode
    ap.add_argument("--kv-len", type=int, default=131072)  # single mode
    ap.add_argument("--q-heads", type=int, default=32)
    ap.add_argument("--kv-heads", type=int, default=2)
    ap.add_argument("--head-dim", type=int, default=256)
    ap.add_argument("--splits", type=int, default=512)
    ap.add_argument("--splits-mode", choices=["static", "heuristic"], default="static")
    ap.add_argument("--max-kv-splits", type=int, default=0, help="0 = match policy max")
    ap.add_argument("--iters", type=int, default=50)
    ap.add_argument("--warmup", type=int, default=10)
    ap.add_argument("--which", default="cuda_stage1,cuda_full,triton_full")
    args = ap.parse_args()

    assert CUDA, "GPU required"
    dev = "cuda"
    sm_count = torch.cuda.get_device_properties(0).multi_processor_count
    cfg = _make_cfg(args.head_dim, dev)
    print(f"# device={torch.cuda.get_device_name(0)} sm_count={sm_count} "
          f"q_heads={args.q_heads} kv_heads={args.kv_heads} head_dim={args.head_dim}")

    if args.mode == "single":
        batches = [args.batch]
        kv_lens = [args.kv_len]
    else:
        batches = [int(x) for x in args.batches.split(",")]
        kv_lens = [int(x) for x in args.kv_lens.split(",")]

    # Build one pool sized to the max (batch*kv_len) across the sweep.
    max_total = max(b * k for b in batches for k in kv_lens)
    print(f"# building KV pool: {max_total} tokens "
          f"(~{max_total * args.kv_heads * (args.head_dim // 2) * 2 / 1e9:.2f} GB packed K+V)")
    torch.manual_seed(0)
    K_raw = torch.randn(max_total, args.kv_heads, args.head_dim, device=dev, dtype=torch.bfloat16)
    V_raw = torch.randn(max_total, args.kv_heads, args.head_dim, device=dev, dtype=torch.bfloat16)
    pool = _pack_pool(K_raw, V_raw, cfg, dev)
    del K_raw, V_raw
    torch.cuda.empty_cache()

    which = args.which.split(",")
    hdr = f"{'batch':>6} {'kv_len':>8} {'splits':>10} {'maxspl':>7}"
    for w in which:
        hdr += f" {w:>13}"
    if "cuda_full" in which and "cuda_stage1" in which:
        hdr += f" {'stage2_us':>11}"
    print(hdr)

    for b in batches:
        for klen in kv_lens:
            if b * klen > max_total:
                continue
            seq_lens = torch.full((b,), klen, dtype=torch.int64, device=dev)
            if args.splits_mode == "heuristic":
                nks = _heuristic_splits(
                    seq_lens, args.q_heads, args.kv_heads,
                    args.splits if args.max_kv_splits == 0 else args.max_kv_splits,
                    sm_count,
                )
                spl_desc = f"heur~{int(nks.float().mean().item())}"
                maxspl = args.max_kv_splits if args.max_kv_splits else int(nks.max().item())
            else:
                nks = torch.full((b,), args.splits, dtype=torch.int32, device=dev)
                spl_desc = str(args.splits)
                maxspl = args.max_kv_splits if args.max_kv_splits else args.splits
            # grid is sized from maxspl; honor invariant num_kv_splits<=maxspl
            assert int(nks.max().item()) <= maxspl, (
                f"num_kv_splits max {int(nks.max().item())} > maxspl {maxspl}"
            )
            inp = Inputs(pool, b, klen, args.q_heads, args.kv_heads, args.head_dim,
                         nks, maxspl, cfg, dev)
            row = f"{b:>6} {klen:>8} {spl_desc:>10} {maxspl:>7}"
            res = {}
            for w in which:
                fn = getattr(inp, w)
                res[w] = time_us(fn, args.iters, args.warmup)
                row += f" {res[w]:>12.2f}"
            if "cuda_full" in res and "cuda_stage1" in res:
                row += f" {res['cuda_full'] - res['cuda_stage1']:>10.2f}"
            print(row, flush=True)


if __name__ == "__main__":
    main()
