from __future__ import annotations

import torch
import triton
import triton.language as tl

# =============================================================================
# Strided-input l2norm for the FlashQLA extend glue.
#
# The GDN extend path hands FlashQLA q/k as torch.split views of the packed
# post-conv mixed_qkv [T, qkv_dim] (row stride = full qkv width). FlashQLA's
# l2norm requires a contiguous input (x.view(-1, D)), so the glue previously
# ran q.contiguous() + l2norm(q): four full memory passes per tensor (copy
# read+write, then norm read+write). This kernel reads the strided view
# directly and writes the l2-normalized contiguous output in a single pass.
#
# Numerics mirror flash_qla.utils.math.l2norm_compiled exactly: upcast to
# fp32, sum(x*x) over the head dim, rsqrt(sum + eps), multiply in fp32, cast
# back to the input dtype.
# =============================================================================


@triton.jit
def _l2norm_gather_kernel(
    x_ptr,
    out_ptr,
    T,
    stride_t,
    stride_h,
    EPS: tl.constexpr,
    H: tl.constexpr,
    D: tl.constexpr,
    BLOCK_T: tl.constexpr,
    RSQRT: tl.constexpr,
):
    pid_t = tl.program_id(0)
    h = tl.program_id(1)
    t = pid_t * BLOCK_T + tl.arange(0, BLOCK_T)
    mask = t < T
    d = tl.arange(0, D)
    x = tl.load(
        x_ptr + t[:, None] * stride_t + h * stride_h + d[None, :],
        mask=mask[:, None],
        other=0.0,
    ).to(tl.float32)
    if RSQRT:
        inv = tl.rsqrt(tl.sum(x * x, axis=1) + EPS)
        y = x * inv[:, None]
    else:
        y = x / tl.sqrt(tl.sum(x * x, axis=1) + EPS)[:, None]
    tl.store(
        out_ptr + t[:, None] * (H * D) + h * D + d[None, :],
        y.to(out_ptr.dtype.element_ty),
        mask=mask[:, None],
    )


def l2norm_gather(
    x: torch.Tensor, eps: float = 1e-6, use_rsqrt: bool = True
) -> torch.Tensor:
    """l2norm over the last dim of a [1, T, H, D] (or [T, H, D]) view whose
    last dim is contiguous; the T/H dims may be arbitrarily strided. Returns a
    fresh CONTIGUOUS tensor of x.shape — the strided source is never
    materialized.

    use_rsqrt=True matches FlashQLA's l2norm_compiled (x * rsqrt(sum + eps));
    use_rsqrt=False matches FLA's l2norm_fwd (x / sqrt(sum + eps)) bit-exactly.
    """
    assert x.stride(-1) == 1, "head dim must be contiguous"
    squeeze = x.dim() == 3
    if squeeze:
        x = x.unsqueeze(0)
    _, T, H, D = x.shape
    out = torch.empty(x.shape, dtype=x.dtype, device=x.device)
    BLOCK_T = 32
    grid = (triton.cdiv(T, BLOCK_T), H)
    _l2norm_gather_kernel[grid](
        x,
        out,
        T,
        x.stride(1),
        x.stride(2),
        eps,
        H,
        D,
        BLOCK_T,
        RSQRT=use_rsqrt,
        num_warps=4,
        num_stages=2,
    )
    return out.squeeze(0) if squeeze else out
