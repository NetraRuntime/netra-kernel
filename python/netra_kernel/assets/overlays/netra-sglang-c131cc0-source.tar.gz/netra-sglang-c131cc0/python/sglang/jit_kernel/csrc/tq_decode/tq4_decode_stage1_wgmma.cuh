#pragma once

/*
 * TQ4 Decode Attention Stage1 — FA3-class Hopper WGMMA (sm_90a warpgroup
 * tensor-core) variant (hd=256). EXPERIMENT, env-gated NETRA_TQ4_DECODE_WGMMA=1.
 *
 * Motivation (vs the WMMA experiment, which was ~10x slower for decode's tiny
 * M=8): the WMMA path mapped M->q-heads (group=8), under-filling the 16-wide MMA
 * and serializing on single-warp per-mma fragment staging. This kernel uses the
 * FA3 TRANSPOSED layout so the WGMMA M dimension is FILLED with 64 tokens, and a
 * warpgroup (4 warps, async wgmma) instead of a single warp:
 *
 *   QK:  S^T[64 tok][8 qh] = K[64 tok][256 hd] @ Q^T[256 hd][8 qh]
 *        wgmma m64n8k16: M=64 tokens (filled), N=8 q-heads, K=hd (16 k-steps).
 *   PV:  O^T[256 hd][8 qh] = V^T[256 hd][64 tok] @ P^T[64 tok][8 qh]
 *        wgmma m64n8k16: M=hd (4 m-tiles of 64), N=8 q-heads, K=tok (4 k-steps).
 *
 * Online softmax runs over the token (M) dimension per q-head. Because that is a
 * cross-warp reduction in the wgmma C-fragment, we do it in SMEM: store S^T ->
 * smem, reduce per-column over the 64 tokens, write P^T (the PV B-operand) back
 * to smem. The O^T accumulator stays RESIDENT in wgmma registers across the
 * token loop, rescaled by exp(m_old - m_new) per q-head each tile (FA3 line 21).
 *
 * Dequant: K/V stored WHT-rotated, 4-bit uniform packed (head_dim/2=128 uint8/
 * head) + bf16 dequant_scale per (token, kv_head). Uniform centroids are affine
 * (centroid[c] = c0 + c*step). Since dscale is per (token,kv_head) it FACTORS OUT
 * of the dot: feed centroids (c0+code*step, no dscale) to wgmma; scale S^T rows
 * by k_dscale[tok]*sm_scale; fold v_dscale[tok] into P^T (matches the scalar
 * cp.async kernel).
 *
 * Operands come from smem via cute GMMA matrix descriptors (no-swizzle / INTER
 * layout, validated err=0 by a standalone probe). KV is GATHERED via
 * kv_indices[tok] (a scatter) so TMA cannot be used; producer dequant writes the
 * gathered, dequanted bf16 tiles into the cute smem operands directly.
 *
 * CUDA-graph discipline mirrors the cp.async kernel: grid batch dim from
 * Q.shape()[0] (NOT att_out, which is oversized to max_num_tokens under graph);
 * empty splits write the exact -FLT_MAX sentinel the stage2 reduce skips.
 *
 * Requires -gencode=arch=compute_90a,code=sm_90a (wgmma won't assemble under
 * plain sm_90). The python wrapper loads this in a separate JIT module under
 * override_jit_cuda_arch(9,0,"a") + extra_dependencies=["cutlass"].
 */

#include <sgl_kernel/tensor.h>
#include <sgl_kernel/utils.cuh>

#include <cuda_bf16.h>
#include <cuda_pipeline.h>
#include <float.h>
#include <cstdint>

#include <cute/tensor.hpp>
#include <cute/atom/mma_atom.hpp>
#include <cutlass/numeric_types.h>

namespace tq4_wgmma {

using namespace cute;

using Bf16 = cute::bfloat16_t;

constexpr int HEAD_DIM = 256;
constexpr int PACKED_DIM = 128;     // head_dim / 2 (bytes per token per head)
constexpr int BLOCK_N = 64;         // tokens per tile = wgmma M for QK
constexpr int QH_TILE = 8;          // q-heads per block (= GQA group)
constexpr int WG_THREADS = 128;     // one warpgroup
constexpr int MIN_BLOCK_KV = 64;    // split alignment (multiple of BLOCK_N)

__device__ __forceinline__ float warp_max(float v) {
#pragma unroll
  for (int o = 16; o > 0; o >>= 1) v = fmaxf(v, __shfl_xor_sync(0xffffffff, v, o));
  return v;
}
__device__ __forceinline__ float warp_sum(float v) {
#pragma unroll
  for (int o = 16; o > 0; o >>= 1) v += __shfl_xor_sync(0xffffffff, v, o);
  return v;
}

// Canonical no-swizzle (INTER) K-major smem operand layouts.
using SmemLayoutK = decltype(tile_to_shape(
    GMMA::Layout_K_INTER_Atom<Bf16>{}, Shape<Int<BLOCK_N>, Int<HEAD_DIM>>{}));   // (tok, hd)
using SmemLayoutQ = decltype(tile_to_shape(
    GMMA::Layout_K_INTER_Atom<Bf16>{}, Shape<Int<QH_TILE>, Int<HEAD_DIM>>{}));   // (qh, hd)
using SmemLayoutV = decltype(tile_to_shape(
    GMMA::Layout_K_INTER_Atom<Bf16>{}, Shape<Int<HEAD_DIM>, Int<BLOCK_N>>{}));   // (hd, tok)
using SmemLayoutP = decltype(tile_to_shape(
    GMMA::Layout_K_INTER_Atom<Bf16>{}, Shape<Int<QH_TILE>, Int<BLOCK_N>>{}));    // (qh, tok)

using MmaQK = decltype(make_tiled_mma(
    SM90_64x8x16_F32BF16BF16_SS<GMMA::Major::K, GMMA::Major::K>{}));
using MmaPV = decltype(make_tiled_mma(
    SM90_64x8x16_F32BF16BF16_SS<GMMA::Major::K, GMMA::Major::K>{}));

struct SharedStorage {
  alignas(128) cute::ArrayEngine<Bf16, cute::cosize_v<SmemLayoutK>> sK;
  alignas(128) cute::ArrayEngine<Bf16, cute::cosize_v<SmemLayoutV>> sV;
  alignas(128) cute::ArrayEngine<Bf16, cute::cosize_v<SmemLayoutQ>> sQ;
  alignas(128) cute::ArrayEngine<Bf16, cute::cosize_v<SmemLayoutP>> sP;
  alignas(16) float s_S[BLOCK_N * QH_TILE];   // S^T[tok][qh] (row-major)
  alignas(16) float s_kds[BLOCK_N];           // k_dscale per token (this tile)
  alignas(16) float s_vds[BLOCK_N];           // v_dscale per token (this tile)
  alignas(16) float s_emax[QH_TILE];
  alignas(16) float s_esum[QH_TILE];
  alignas(16) float s_corr[QH_TILE];
};

__global__ __launch_bounds__(WG_THREADS) void tq4_decode_stage1_wgmma_kernel(
    const __nv_bfloat16* __restrict__ Q,
    const uint8_t* __restrict__ K_packed,
    const uint8_t* __restrict__ V_packed,
    const __nv_bfloat16* __restrict__ K_dscale,
    const __nv_bfloat16* __restrict__ V_dscale,
    const int32_t* __restrict__ kv_indptr,
    const int64_t* __restrict__ kv_indices,
    const int32_t* __restrict__ num_kv_splits,
    float* __restrict__ att_out,
    float* __restrict__ att_lse,
    const float* __restrict__ k_centroids,
    const float* __restrict__ v_centroids,
    float sm_scale,
    int H_Q, int H_KV, int max_kv_splits,
    int stride_q_batch, int stride_q_head,
    int stride_kp_pool, int stride_kp_head,
    int stride_vp_pool, int stride_vp_head,
    int stride_kds_pool, int stride_vds_pool,
    int stride_att_batch, int stride_att_head, int stride_att_split,
    int kv_group_num) {
  const int batch_id = blockIdx.x;
  const int chunks_per_kv = (kv_group_num + QH_TILE - 1) / QH_TILE;
  const int kv_head = blockIdx.y / chunks_per_kv;
  const int chunk = blockIdx.y % chunks_per_kv;
  const int qh_base = kv_head * kv_group_num + chunk * QH_TILE;
  const int qh_count = min(QH_TILE, kv_group_num - chunk * QH_TILE);
  const int split_id = blockIdx.z;
  const int tid = threadIdx.x;

  extern __shared__ char smem_raw[];
  SharedStorage& sm = *reinterpret_cast<SharedStorage*>(smem_raw);

  // Affine uniform centroid: centroid[c] = c0 + c*step (no LUT).
  const float k_c0 = k_centroids[0];
  const float k_step = (k_centroids[15] - k_centroids[0]) * (1.0f / 15.0f);
  const float v_c0 = v_centroids[0];
  const float v_step = (v_centroids[15] - v_centroids[0]) * (1.0f / 15.0f);

  // Load Q (this block's q-head tile) into sQ[qh][hd], rotated bf16 as-is.
  Tensor tQ = make_tensor(make_smem_ptr(sm.sQ.begin()), SmemLayoutQ{});
  for (int idx = tid; idx < QH_TILE * HEAD_DIM; idx += WG_THREADS) {
    int h = idx / HEAD_DIM;
    int d = idx % HEAD_DIM;
    float qv = 0.0f;
    if (h < qh_count)
      qv = __bfloat162float(Q[batch_id * stride_q_batch + (qh_base + h) * stride_q_head + d]);
    tQ(h, d) = static_cast<Bf16>(qv);
  }

  if (split_id >= max_kv_splits) return;

  const int kv_start = kv_indptr[batch_id];
  const int kv_end = kv_indptr[batch_id + 1];
  const int kv_len = kv_end - kv_start;
  const int n_splits = num_kv_splits[batch_id];
  const int split_len = (kv_len + n_splits - 1) / n_splits;
  const int aligned_len = ((split_len + MIN_BLOCK_KV - 1) / MIN_BLOCK_KV) * MIN_BLOCK_KV;
  const int my_start = kv_start + split_id * aligned_len;
  const int my_end = min(my_start + aligned_len, kv_end);

  if (my_start >= kv_end) {
    if (tid < qh_count)
      att_lse[batch_id * H_Q * max_kv_splits + (qh_base + tid) * max_kv_splits + split_id] =
          -FLT_MAX;
    return;
  }

  // Persistent register accumulator for O^T[256 hd][8 qh] and its (hd,qh) coords.
  MmaPV mma_pv;
  ThrMMA thr_pv = mma_pv.get_slice(tid);
  Tensor acc_o = partition_fragment_C(mma_pv, Shape<Int<HEAD_DIM>, Int<QH_TILE>>{});  // (MMA,M,N)
  Tensor cO = thr_pv.partition_C(make_identity_tensor(Shape<Int<HEAD_DIM>, Int<QH_TILE>>{}));
  clear(acc_o);

  if (tid < QH_TILE) {
    sm.s_emax[tid] = -FLT_MAX;
    sm.s_esum[tid] = 0.0f;
  }
  __syncthreads();

  MmaQK mma_qk;
  ThrMMA thr_qk = mma_qk.get_slice(tid);

  Tensor tK = make_tensor(make_smem_ptr(sm.sK.begin()), SmemLayoutK{});  // (tok, hd)
  Tensor tV = make_tensor(make_smem_ptr(sm.sV.begin()), SmemLayoutV{});  // (hd, tok)
  Tensor tP = make_tensor(make_smem_ptr(sm.sP.begin()), SmemLayoutP{});  // (qh, tok)
  Tensor tS = make_tensor(make_smem_ptr(sm.s_S),
                          make_layout(Shape<Int<BLOCK_N>, Int<QH_TILE>>{},
                                      Stride<Int<QH_TILE>, Int<1>>{}));

  const int num_tiles = (my_end - my_start + BLOCK_N - 1) / BLOCK_N;

  for (int t = 0; t < num_tiles; t++) {
    const int tok0 = my_start + t * BLOCK_N;
    const int n_valid = min(BLOCK_N, my_end - tok0);

    // --- Producer: gather + dequant this tile's K/V into the wgmma operands ---
    // K -> sK[tok][hd] (centroid, no dscale); V -> sV[hd][tok] (transposed).
    for (int idx = tid; idx < BLOCK_N * PACKED_DIM; idx += WG_THREADS) {
      int tok = idx / PACKED_DIM;       // 0..63
      int pb = idx % PACKED_DIM;        // 0..127 (byte within head)
      bool valid = tok < n_valid;
      int kv_idx = valid ? static_cast<int>(kv_indices[tok0 + tok]) : 0;
      uint8_t kb = 0, vb = 0;
      if (valid) {
        kb = K_packed[kv_idx * stride_kp_pool + kv_head * stride_kp_head + pb];
        vb = V_packed[kv_idx * stride_vp_pool + kv_head * stride_vp_head + pb];
      }
      float k_e = k_c0 + (kb & 0x0F) * k_step;          // hd = 2*pb   (low nibble)
      float k_o = k_c0 + ((kb >> 4) & 0x0F) * k_step;   // hd = 2*pb+1 (high nibble)
      float v_e = v_c0 + (vb & 0x0F) * v_step;
      float v_o = v_c0 + ((vb >> 4) & 0x0F) * v_step;
      if (!valid) { k_e = k_o = v_e = v_o = 0.0f; }
      tK(tok, 2 * pb) = static_cast<Bf16>(k_e);
      tK(tok, 2 * pb + 1) = static_cast<Bf16>(k_o);
      tV(2 * pb, tok) = static_cast<Bf16>(v_e);
      tV(2 * pb + 1, tok) = static_cast<Bf16>(v_o);
    }
    // dscale per token for this tile.
    for (int tok = tid; tok < BLOCK_N; tok += WG_THREADS) {
      bool valid = tok < n_valid;
      int kv_idx = valid ? static_cast<int>(kv_indices[tok0 + tok]) : 0;
      sm.s_kds[tok] = valid ? __bfloat162float(K_dscale[kv_idx * stride_kds_pool + kv_head]) : 0.0f;
      sm.s_vds[tok] = valid ? __bfloat162float(V_dscale[kv_idx * stride_vds_pool + kv_head]) : 0.0f;
    }
    __syncthreads();

    // --- QK: S^T[64 tok][8 qh] = K @ Q^T (16 k-steps over hd) ---
    Tensor tCsK = thr_qk.partition_A(tK);            // (MMA, MMA_M=1, MMA_K=16)
    Tensor tCsQ = thr_qk.partition_B(tQ);            // (MMA, MMA_N=1, MMA_K=16)
    Tensor tCrK = thr_qk.make_fragment_A(tCsK);
    Tensor tCrQ = thr_qk.make_fragment_B(tCsQ);
    Tensor acc_s = partition_fragment_C(mma_qk, Shape<Int<BLOCK_N>, Int<QH_TILE>>{});  // (MMA,1,1)
    clear(acc_s);
    warpgroup_fence_operand(acc_s);
    warpgroup_arrive();
    cute::gemm(mma_qk, tCrK, tCrQ, acc_s);
    warpgroup_commit_batch();
    warpgroup_wait<0>();
    warpgroup_fence_operand(acc_s);

    // Store S^T -> smem s_S[tok][qh].
    Tensor tCsS = thr_qk.partition_C(tS);
    copy(acc_s, tCsS);
    __syncthreads();

    // --- Online softmax over tokens (rows) per q-head (col) ---
    // All 128 threads: warp w owns q-heads {2w, 2w+1}; each lane reduces 2 of the
    // 64 tokens (lane, lane+32) via warp-shuffle. (BLOCK_N=64 = 2*WARP_SIZE.)
    {
      const int warp_id = tid / 32;   // 0..3
      const int lane = tid % 32;      // 0..31
#pragma unroll
      for (int qi = 0; qi < 2; qi++) {
        const int qh = 2 * warp_id + qi;
        if (qh >= qh_count) {
          tP(qh, lane) = static_cast<Bf16>(0.0f);
          tP(qh, lane + 32) = static_cast<Bf16>(0.0f);
          if (lane == 0) sm.s_corr[qh] = 1.0f;
          continue;
        }
        float s0 = -FLT_MAX, s1 = -FLT_MAX;
        if (lane < n_valid) s0 = sm.s_S[lane * QH_TILE + qh] * (sm.s_kds[lane] * sm_scale);
        if (lane + 32 < n_valid)
          s1 = sm.s_S[(lane + 32) * QH_TILE + qh] * (sm.s_kds[lane + 32] * sm_scale);
        float tile_max = warp_max(fmaxf(s0, s1));
        float old_max = sm.s_emax[qh];
        float new_max = fmaxf(old_max, tile_max);
        float corr = __expf(old_max - new_max);
        float p0 = (lane < n_valid) ? __expf(s0 - new_max) : 0.0f;
        float p1 = (lane + 32 < n_valid) ? __expf(s1 - new_max) : 0.0f;
        float tile_sum = warp_sum(p0 + p1);
        tP(qh, lane) = static_cast<Bf16>(p0 * sm.s_vds[lane]);          // fold v_dscale
        tP(qh, lane + 32) = static_cast<Bf16>(p1 * sm.s_vds[lane + 32]);
        if (lane == 0) {
          sm.s_emax[qh] = new_max;
          sm.s_esum[qh] = sm.s_esum[qh] * corr + tile_sum;
          sm.s_corr[qh] = corr;
        }
      }
    }
    __syncthreads();

    // --- Rescale resident O^T accumulator by corr[qh] (FA3 line 21) ---
    CUTE_UNROLL
    for (int i = 0; i < size(acc_o); i++) {
      int qh = get<1>(cO(i));
      acc_o(i) *= sm.s_corr[qh];
    }

    // --- PV: O^T[256 hd][8 qh] += V^T @ P^T (4 m-tiles x 4 k-steps) ---
    Tensor tCsV = thr_pv.partition_A(tV);            // (MMA, MMA_M=4, MMA_K=4)
    Tensor tCsP = thr_pv.partition_B(tP);            // (MMA, MMA_N=1, MMA_K=4)
    Tensor tCrV = thr_pv.make_fragment_A(tCsV);
    Tensor tCrP = thr_pv.make_fragment_B(tCsP);
    warpgroup_fence_operand(acc_o);
    warpgroup_arrive();
    cute::gemm(mma_pv, tCrV, tCrP, acc_o);
    warpgroup_commit_batch();
    warpgroup_wait<0>();
    warpgroup_fence_operand(acc_o);
    __syncthreads();  // protect sP/sK/sV reuse next tile
  }

  // --- Write normalized per-split O + lse ---
  // acc_o(i) -> (hd, qh); att_out[b][qh_base+qh][split][hd], att_lse[...][qh].
  CUTE_UNROLL
  for (int i = 0; i < size(acc_o); i++) {
    int hd = get<0>(cO(i));
    int qh = get<1>(cO(i));
    if (qh < qh_count) {
      float es = sm.s_esum[qh];
      float inv = (es > 0.0f) ? (1.0f / es) : 0.0f;
      att_out[batch_id * stride_att_batch + (qh_base + qh) * stride_att_head +
              split_id * stride_att_split + hd] = acc_o(i) * inv;
    }
  }
  if (tid < qh_count) {
    int qh = tid;
    att_lse[batch_id * H_Q * max_kv_splits + (qh_base + qh) * max_kv_splits + split_id] =
        sm.s_emax[qh] + logf(fmaxf(sm.s_esum[qh], 1e-10f));
  }
}

// -- host launcher (TVM-FFI) -----------------------------------------------
void tq4_decode_stage1_wgmma_launch(
    tvm::ffi::TensorView Q, tvm::ffi::TensorView K_packed, tvm::ffi::TensorView V_packed,
    tvm::ffi::TensorView K_dscale, tvm::ffi::TensorView V_dscale,
    tvm::ffi::TensorView kv_indptr, tvm::ffi::TensorView kv_indices,
    tvm::ffi::TensorView num_kv_splits,
    tvm::ffi::TensorView att_out, tvm::ffi::TensorView att_lse,
    tvm::ffi::TensorView k_centroids, tvm::ffi::TensorView v_centroids,
    double sm_scale, int64_t max_kv_splits) {
  using namespace host;
  const DLDevice device = Q.device();

  // Grid batch dim from Q (sized to real bs), NOT att_out (oversized under graph).
  const int batch = static_cast<int>(Q.shape()[0]);
  const int h_q = static_cast<int>(Q.shape()[1]);
  const int h_kv = static_cast<int>(K_packed.shape()[1]);
  const int kv_group = h_q / h_kv;
  const int chunks_per_kv = (kv_group + QH_TILE - 1) / QH_TILE;
  const int max_splits = static_cast<int>(max_kv_splits);

  dim3 grid(batch, h_kv * chunks_per_kv, max_splits);
  dim3 block(WG_THREADS);
  const int smem_bytes = static_cast<int>(sizeof(SharedStorage));

  cudaFuncSetAttribute(tq4_decode_stage1_wgmma_kernel,
                       cudaFuncAttributeMaxDynamicSharedMemorySize, smem_bytes);

  LaunchKernel(grid, block, device, static_cast<std::size_t>(smem_bytes))(
      tq4_decode_stage1_wgmma_kernel,
      static_cast<const __nv_bfloat16*>(Q.data_ptr()),
      static_cast<const uint8_t*>(K_packed.data_ptr()),
      static_cast<const uint8_t*>(V_packed.data_ptr()),
      static_cast<const __nv_bfloat16*>(K_dscale.data_ptr()),
      static_cast<const __nv_bfloat16*>(V_dscale.data_ptr()),
      static_cast<const int32_t*>(kv_indptr.data_ptr()),
      static_cast<const int64_t*>(kv_indices.data_ptr()),
      static_cast<const int32_t*>(num_kv_splits.data_ptr()),
      static_cast<float*>(att_out.data_ptr()),
      static_cast<float*>(att_lse.data_ptr()),
      static_cast<const float*>(k_centroids.data_ptr()),
      static_cast<const float*>(v_centroids.data_ptr()),
      static_cast<float>(sm_scale),
      h_q, h_kv, max_splits,
      static_cast<int>(Q.stride(0)), static_cast<int>(Q.stride(1)),
      static_cast<int>(K_packed.stride(0)), static_cast<int>(K_packed.stride(1)),
      static_cast<int>(V_packed.stride(0)), static_cast<int>(V_packed.stride(1)),
      static_cast<int>(K_dscale.stride(0)), static_cast<int>(V_dscale.stride(0)),
      static_cast<int>(att_out.stride(0)), static_cast<int>(att_out.stride(1)),
      static_cast<int>(att_out.stride(2)),
      kv_group);
}

// =====================================================================
// fp8 (e4m3) variant. Halves the operand-smem materialization (32->16 KB
// per K/V tile -> better occupancy) and uses fp8 tensor cores (k32). The
// 4-bit codes map to centroid = step*(code-7.5) since c0=-7.5*step (uniform
// linspace(-2.5s,2.5s,16)). We feed (code-7.5) as the fp8 operand: those
// half-integers (+-0.5..+-7.5) are EXACT in e4m3, so K/V take ZERO fp8 error
// beyond the existing 4-bit quant; only Q and P*v_dscale take the fp8 hit.
// `step` is folded into the per-token logit scale (K) / final O scale (V).
// =====================================================================
using E4 = cutlass::float_e4m3_t;

using SmemLayoutKf = decltype(tile_to_shape(
    GMMA::Layout_K_INTER_Atom<E4>{}, Shape<Int<BLOCK_N>, Int<HEAD_DIM>>{}));
using SmemLayoutQf = decltype(tile_to_shape(
    GMMA::Layout_K_INTER_Atom<E4>{}, Shape<Int<QH_TILE>, Int<HEAD_DIM>>{}));
using SmemLayoutVf = decltype(tile_to_shape(
    GMMA::Layout_K_INTER_Atom<E4>{}, Shape<Int<HEAD_DIM>, Int<BLOCK_N>>{}));
using SmemLayoutPf = decltype(tile_to_shape(
    GMMA::Layout_K_INTER_Atom<E4>{}, Shape<Int<QH_TILE>, Int<BLOCK_N>>{}));

// fp8 wgmma is TN-only (no transpose modes): A K-major, B K-major.
using MmaQKf = decltype(make_tiled_mma(SM90_64x8x32_F32E4M3E4M3_SS_TN<>{}));
using MmaPVf = decltype(make_tiled_mma(SM90_64x8x32_F32E4M3E4M3_SS_TN<>{}));

struct SharedStorageF {
  alignas(128) cute::ArrayEngine<E4, cute::cosize_v<SmemLayoutKf>> sK;
  alignas(128) cute::ArrayEngine<E4, cute::cosize_v<SmemLayoutVf>> sV;
  alignas(128) cute::ArrayEngine<E4, cute::cosize_v<SmemLayoutQf>> sQ;
  alignas(128) cute::ArrayEngine<E4, cute::cosize_v<SmemLayoutPf>> sP;
  // cp.async double-buffered GATHERED packed K/V staging (uint4-aligned).
  alignas(16) uint8_t s_Kp[2][BLOCK_N * PACKED_DIM];
  alignas(16) uint8_t s_Vp[2][BLOCK_N * PACKED_DIM];
  alignas(16) float s_S[BLOCK_N * QH_TILE];
  alignas(16) float s_kds[BLOCK_N];
  alignas(16) float s_vds[BLOCK_N];
  alignas(16) float s_emax[QH_TILE];
  alignas(16) float s_esum[QH_TILE];
  alignas(16) float s_corr[QH_TILE];
};

__global__ __launch_bounds__(WG_THREADS) void tq4_decode_stage1_wgmma_fp8_kernel(
    const __nv_bfloat16* __restrict__ Q,
    const uint8_t* __restrict__ K_packed,
    const uint8_t* __restrict__ V_packed,
    const __nv_bfloat16* __restrict__ K_dscale,
    const __nv_bfloat16* __restrict__ V_dscale,
    const int32_t* __restrict__ kv_indptr,
    const int64_t* __restrict__ kv_indices,
    const int32_t* __restrict__ num_kv_splits,
    float* __restrict__ att_out,
    float* __restrict__ att_lse,
    const float* __restrict__ k_centroids,
    const float* __restrict__ v_centroids,
    float sm_scale,
    int H_Q, int H_KV, int max_kv_splits,
    int stride_q_batch, int stride_q_head,
    int stride_kp_pool, int stride_kp_head,
    int stride_vp_pool, int stride_vp_head,
    int stride_kds_pool, int stride_vds_pool,
    int stride_att_batch, int stride_att_head, int stride_att_split,
    int kv_group_num) {
  const int batch_id = blockIdx.x;
  const int chunks_per_kv = (kv_group_num + QH_TILE - 1) / QH_TILE;
  const int kv_head = blockIdx.y / chunks_per_kv;
  const int chunk = blockIdx.y % chunks_per_kv;
  const int qh_base = kv_head * kv_group_num + chunk * QH_TILE;
  const int qh_count = min(QH_TILE, kv_group_num - chunk * QH_TILE);
  const int split_id = blockIdx.z;
  const int tid = threadIdx.x;

  extern __shared__ char smem_raw[];
  SharedStorageF& sm = *reinterpret_cast<SharedStorageF*>(smem_raw);

  // step folded into scales; operand = (code - 7.5).
  const float k_step = (k_centroids[15] - k_centroids[0]) * (1.0f / 15.0f);
  const float v_step = (v_centroids[15] - v_centroids[0]) * (1.0f / 15.0f);

  Tensor tQ = make_tensor(make_smem_ptr(sm.sQ.begin()), SmemLayoutQf{});
  for (int idx = tid; idx < QH_TILE * HEAD_DIM; idx += WG_THREADS) {
    int h = idx / HEAD_DIM;
    int d = idx % HEAD_DIM;
    float qv = 0.0f;
    if (h < qh_count)
      qv = __bfloat162float(Q[batch_id * stride_q_batch + (qh_base + h) * stride_q_head + d]);
    tQ(h, d) = static_cast<E4>(qv);
  }

  if (split_id >= max_kv_splits) return;

  const int kv_start = kv_indptr[batch_id];
  const int kv_end = kv_indptr[batch_id + 1];
  const int kv_len = kv_end - kv_start;
  const int n_splits = num_kv_splits[batch_id];
  const int split_len = (kv_len + n_splits - 1) / n_splits;
  const int aligned_len = ((split_len + MIN_BLOCK_KV - 1) / MIN_BLOCK_KV) * MIN_BLOCK_KV;
  const int my_start = kv_start + split_id * aligned_len;
  const int my_end = min(my_start + aligned_len, kv_end);

  if (my_start >= kv_end) {
    if (tid < qh_count)
      att_lse[batch_id * H_Q * max_kv_splits + (qh_base + tid) * max_kv_splits + split_id] =
          -FLT_MAX;
    return;
  }

  MmaPVf mma_pv;
  ThrMMA thr_pv = mma_pv.get_slice(tid);
  Tensor acc_o = partition_fragment_C(mma_pv, Shape<Int<HEAD_DIM>, Int<QH_TILE>>{});
  Tensor cO = thr_pv.partition_C(make_identity_tensor(Shape<Int<HEAD_DIM>, Int<QH_TILE>>{}));
  clear(acc_o);

  if (tid < QH_TILE) {
    sm.s_emax[tid] = -FLT_MAX;
    sm.s_esum[tid] = 0.0f;
  }
  __syncthreads();

  MmaQKf mma_qk;
  ThrMMA thr_qk = mma_qk.get_slice(tid);

  Tensor tK = make_tensor(make_smem_ptr(sm.sK.begin()), SmemLayoutKf{});
  Tensor tV = make_tensor(make_smem_ptr(sm.sV.begin()), SmemLayoutVf{});
  Tensor tP = make_tensor(make_smem_ptr(sm.sP.begin()), SmemLayoutPf{});
  Tensor tS = make_tensor(make_smem_ptr(sm.s_S),
                          make_layout(Shape<Int<BLOCK_N>, Int<QH_TILE>>{},
                                      Stride<Int<QH_TILE>, Int<1>>{}));

  const int num_tiles = (my_end - my_start + BLOCK_N - 1) / BLOCK_N;
  constexpr int PVEC = PACKED_DIM / 16;  // uint4 chunks per token per head (8)

  // cp.async-load tile (t)'s GATHERED packed K/V into staging buffer (buf).
#define FP8_LOAD_TILE(t, buf)                                                            \
  do {                                                                                   \
    int _tok0 = my_start + (t) * BLOCK_N;                                                \
    int _nv = min(BLOCK_N, my_end - _tok0);                                              \
    for (int _i = tid; _i < BLOCK_N * PVEC; _i += WG_THREADS) {                          \
      int _tok = _i / PVEC, _v = _i % PVEC;                                              \
      if (_tok < _nv) {                                                                  \
        int _kv = static_cast<int>(kv_indices[_tok0 + _tok]);                            \
        const uint4* _ks = reinterpret_cast<const uint4*>(                               \
            K_packed + _kv * stride_kp_pool + kv_head * stride_kp_head) + _v;            \
        const uint4* _vs = reinterpret_cast<const uint4*>(                               \
            V_packed + _kv * stride_vp_pool + kv_head * stride_vp_head) + _v;            \
        __pipeline_memcpy_async(&sm.s_Kp[buf][_tok * PACKED_DIM + _v * 16], _ks, 16);    \
        __pipeline_memcpy_async(&sm.s_Vp[buf][_tok * PACKED_DIM + _v * 16], _vs, 16);    \
      }                                                                                  \
    }                                                                                    \
  } while (0)

  FP8_LOAD_TILE(0, 0);
  __pipeline_commit();

  for (int t = 0; t < num_tiles; t++) {
    const int buf = t & 1;
    if (t + 1 < num_tiles) {
      FP8_LOAD_TILE(t + 1, (t + 1) & 1);
      __pipeline_commit();
    }
    __pipeline_wait_prior((t + 1 < num_tiles) ? 1 : 0);
    __syncthreads();

    const int tok0 = my_start + t * BLOCK_N;
    const int n_valid = min(BLOCK_N, my_end - tok0);

    // dequant gathered packed (smem) -> fp8 operands; (code-7.5) exact in e4m3.
    for (int idx = tid; idx < BLOCK_N * PACKED_DIM; idx += WG_THREADS) {
      int tok = idx / PACKED_DIM;
      int pb = idx % PACKED_DIM;
      float k_e = 0.0f, k_o = 0.0f, v_e = 0.0f, v_o = 0.0f;
      if (tok < n_valid) {
        uint8_t kb = sm.s_Kp[buf][tok * PACKED_DIM + pb];
        uint8_t vb = sm.s_Vp[buf][tok * PACKED_DIM + pb];
        k_e = (kb & 0x0F) - 7.5f;
        k_o = ((kb >> 4) & 0x0F) - 7.5f;
        v_e = (vb & 0x0F) - 7.5f;
        v_o = ((vb >> 4) & 0x0F) - 7.5f;
      }
      tK(tok, 2 * pb) = static_cast<E4>(k_e);
      tK(tok, 2 * pb + 1) = static_cast<E4>(k_o);
      tV(2 * pb, tok) = static_cast<E4>(v_e);
      tV(2 * pb + 1, tok) = static_cast<E4>(v_o);
    }
    for (int tok = tid; tok < BLOCK_N; tok += WG_THREADS) {
      bool valid = tok < n_valid;
      int kv_idx = valid ? static_cast<int>(kv_indices[tok0 + tok]) : 0;
      sm.s_kds[tok] = valid ? __bfloat162float(K_dscale[kv_idx * stride_kds_pool + kv_head]) : 0.0f;
      sm.s_vds[tok] = valid ? __bfloat162float(V_dscale[kv_idx * stride_vds_pool + kv_head]) : 0.0f;
    }
    __syncthreads();

    // QK: S^T = K @ Q^T (8 k-steps of 32 over hd=256).
    Tensor tCsK = thr_qk.partition_A(tK);
    Tensor tCsQ = thr_qk.partition_B(tQ);
    Tensor tCrK = thr_qk.make_fragment_A(tCsK);
    Tensor tCrQ = thr_qk.make_fragment_B(tCsQ);
    Tensor acc_s = partition_fragment_C(mma_qk, Shape<Int<BLOCK_N>, Int<QH_TILE>>{});
    clear(acc_s);
    warpgroup_fence_operand(acc_s);
    warpgroup_arrive();
    cute::gemm(mma_qk, tCrK, tCrQ, acc_s);
    warpgroup_commit_batch();
    warpgroup_wait<0>();
    warpgroup_fence_operand(acc_s);

    Tensor tCsS = thr_qk.partition_C(tS);
    copy(acc_s, tCsS);
    __syncthreads();

    // Online softmax over tokens; logit = step_K * k_dscale * sm_scale * S_wgmma.
    {
      const int warp_id = tid / 32;
      const int lane = tid % 32;
#pragma unroll
      for (int qi = 0; qi < 2; qi++) {
        const int qh = 2 * warp_id + qi;
        if (qh >= qh_count) {
          tP(qh, lane) = static_cast<E4>(0.0f);
          tP(qh, lane + 32) = static_cast<E4>(0.0f);
          if (lane == 0) sm.s_corr[qh] = 1.0f;
          continue;
        }
        float s0 = -FLT_MAX, s1 = -FLT_MAX;
        if (lane < n_valid)
          s0 = sm.s_S[lane * QH_TILE + qh] * (k_step * sm.s_kds[lane] * sm_scale);
        if (lane + 32 < n_valid)
          s1 = sm.s_S[(lane + 32) * QH_TILE + qh] * (k_step * sm.s_kds[lane + 32] * sm_scale);
        float tile_max = warp_max(fmaxf(s0, s1));
        float old_max = sm.s_emax[qh];
        float new_max = fmaxf(old_max, tile_max);
        float corr = __expf(old_max - new_max);
        float p0 = (lane < n_valid) ? __expf(s0 - new_max) : 0.0f;
        float p1 = (lane + 32 < n_valid) ? __expf(s1 - new_max) : 0.0f;
        float tile_sum = warp_sum(p0 + p1);
        tP(qh, lane) = static_cast<E4>(p0 * sm.s_vds[lane]);
        tP(qh, lane + 32) = static_cast<E4>(p1 * sm.s_vds[lane + 32]);
        if (lane == 0) {
          sm.s_emax[qh] = new_max;
          sm.s_esum[qh] = sm.s_esum[qh] * corr + tile_sum;
          sm.s_corr[qh] = corr;
        }
      }
    }
    __syncthreads();

    CUTE_UNROLL
    for (int i = 0; i < size(acc_o); i++) acc_o(i) *= sm.s_corr[get<1>(cO(i))];

    // PV: O^T += V^T @ P^T (4 m-tiles x 2 k-steps of 32 over tok=64).
    Tensor tCsV = thr_pv.partition_A(tV);
    Tensor tCsP = thr_pv.partition_B(tP);
    Tensor tCrV = thr_pv.make_fragment_A(tCsV);
    Tensor tCrP = thr_pv.make_fragment_B(tCsP);
    warpgroup_fence_operand(acc_o);
    warpgroup_arrive();
    cute::gemm(mma_pv, tCrV, tCrP, acc_o);
    warpgroup_commit_batch();
    warpgroup_wait<0>();
    warpgroup_fence_operand(acc_o);
    __syncthreads();
  }

  // Write normalized per-split O + lse. O_true = v_step * O_wgmma.
  CUTE_UNROLL
  for (int i = 0; i < size(acc_o); i++) {
    int hd = get<0>(cO(i));
    int qh = get<1>(cO(i));
    if (qh < qh_count) {
      float es = sm.s_esum[qh];
      float scale = (es > 0.0f) ? (v_step / es) : 0.0f;
      att_out[batch_id * stride_att_batch + (qh_base + qh) * stride_att_head +
              split_id * stride_att_split + hd] = acc_o(i) * scale;
    }
  }
  if (tid < qh_count) {
    int qh = tid;
    att_lse[batch_id * H_Q * max_kv_splits + (qh_base + qh) * max_kv_splits + split_id] =
        sm.s_emax[qh] + logf(fmaxf(sm.s_esum[qh], 1e-10f));
  }
}
#undef FP8_LOAD_TILE

void tq4_decode_stage1_wgmma_fp8_launch(
    tvm::ffi::TensorView Q, tvm::ffi::TensorView K_packed, tvm::ffi::TensorView V_packed,
    tvm::ffi::TensorView K_dscale, tvm::ffi::TensorView V_dscale,
    tvm::ffi::TensorView kv_indptr, tvm::ffi::TensorView kv_indices,
    tvm::ffi::TensorView num_kv_splits,
    tvm::ffi::TensorView att_out, tvm::ffi::TensorView att_lse,
    tvm::ffi::TensorView k_centroids, tvm::ffi::TensorView v_centroids,
    double sm_scale, int64_t max_kv_splits) {
  using namespace host;
  const DLDevice device = Q.device();
  const int batch = static_cast<int>(Q.shape()[0]);
  const int h_q = static_cast<int>(Q.shape()[1]);
  const int h_kv = static_cast<int>(K_packed.shape()[1]);
  const int kv_group = h_q / h_kv;
  const int chunks_per_kv = (kv_group + QH_TILE - 1) / QH_TILE;
  const int max_splits = static_cast<int>(max_kv_splits);

  dim3 grid(batch, h_kv * chunks_per_kv, max_splits);
  dim3 block(WG_THREADS);
  const int smem_bytes = static_cast<int>(sizeof(SharedStorageF));

  cudaFuncSetAttribute(tq4_decode_stage1_wgmma_fp8_kernel,
                       cudaFuncAttributeMaxDynamicSharedMemorySize, smem_bytes);

  LaunchKernel(grid, block, device, static_cast<std::size_t>(smem_bytes))(
      tq4_decode_stage1_wgmma_fp8_kernel,
      static_cast<const __nv_bfloat16*>(Q.data_ptr()),
      static_cast<const uint8_t*>(K_packed.data_ptr()),
      static_cast<const uint8_t*>(V_packed.data_ptr()),
      static_cast<const __nv_bfloat16*>(K_dscale.data_ptr()),
      static_cast<const __nv_bfloat16*>(V_dscale.data_ptr()),
      static_cast<const int32_t*>(kv_indptr.data_ptr()),
      static_cast<const int64_t*>(kv_indices.data_ptr()),
      static_cast<const int32_t*>(num_kv_splits.data_ptr()),
      static_cast<float*>(att_out.data_ptr()),
      static_cast<float*>(att_lse.data_ptr()),
      static_cast<const float*>(k_centroids.data_ptr()),
      static_cast<const float*>(v_centroids.data_ptr()),
      static_cast<float>(sm_scale),
      h_q, h_kv, max_splits,
      static_cast<int>(Q.stride(0)), static_cast<int>(Q.stride(1)),
      static_cast<int>(K_packed.stride(0)), static_cast<int>(K_packed.stride(1)),
      static_cast<int>(V_packed.stride(0)), static_cast<int>(V_packed.stride(1)),
      static_cast<int>(K_dscale.stride(0)), static_cast<int>(V_dscale.stride(0)),
      static_cast<int>(att_out.stride(0)), static_cast<int>(att_out.stride(1)),
      static_cast<int>(att_out.stride(2)),
      kv_group);
}

}  // namespace tq4_wgmma
