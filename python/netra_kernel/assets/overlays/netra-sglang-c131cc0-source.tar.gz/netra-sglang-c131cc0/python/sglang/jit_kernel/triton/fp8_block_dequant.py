from __future__ import annotations

import torch
import triton
import triton.language as tl

# =============================================================================
# Block-scaled fp8 -> fp16/bf16 weight dequant for the large-M dense GEMM path
# on SM80 (A100). Marlin is a small-M dequant-GEMM design; at prefill chunk
# sizes (M >= ~2k) a one-pass dequant followed by a cuBLAS HGEMM is faster
# than marlin (see docs/netra/notes/kernel_profile_a100_2026-07-26.md). This kernel
# reads the ORIGINAL (n, k) float8_e4m3fn weight with its (n/128, k/128) fp32
# block scales — the layout weights have BEFORE marlin repack — and writes the
# dequantized weight in one bandwidth-bound pass.
# =============================================================================


@triton.jit
def _fp8_block_dequant_kernel(
    q_ptr,  # e4m3fn bytes viewed as uint8 (SM80 triton cannot load fp8e4nv)
    s_ptr,
    out_ptr,
    K,
    KB,
    BN: tl.constexpr,
    BK: tl.constexpr,
):
    pid_n = tl.program_id(0)
    pid_k = tl.program_id(1)
    offs_n = pid_n * BN + tl.arange(0, BN)
    offs_k = pid_k * BK + tl.arange(0, BK)
    u = tl.load(q_ptr + offs_n[:, None] * K + offs_k[None, :]).to(tl.uint16)
    # e4m3fn -> fp16 bits: sign to bit 15, exp+mant shifted into e5m10. The
    # result equals the fp8 value * 2^-8 exactly (bias 7 -> 15); the 2^8 is
    # folded into the fp32 scale, so the final product rounds once, exactly
    # like the q.float() * s reference.
    h = ((u & 0x80) << 8) | ((u & 0x7F) << 7)
    f = h.to(tl.float16, bitcast=True).to(tl.float32)
    s = tl.load(s_ptr + pid_n * KB + pid_k) * 256.0
    tl.store(
        out_ptr + offs_n[:, None] * K + offs_k[None, :],
        (f * s).to(out_ptr.dtype.element_ty),
    )


def fp8_block_dequant(
    qweight: torch.Tensor,
    scales: torch.Tensor,
    out_dtype: torch.dtype = torch.float16,
    block_n: int = 128,
    block_k: int = 128,
) -> torch.Tensor:
    """Dequantize a (n, k) float8_e4m3fn weight with (ceil(n/bn), ceil(k/bk))
    fp32 block scales into a fresh (n, k) out_dtype tensor. n and k must be
    multiples of the block sizes (true for every Qwen3.6 dense layer)."""
    n, k = qweight.shape
    assert n % block_n == 0 and k % block_k == 0, (n, k)
    assert qweight.is_contiguous() and scales.is_contiguous()
    out = torch.empty(n, k, dtype=out_dtype, device=qweight.device)
    grid = (n // block_n, k // block_k)
    _fp8_block_dequant_kernel[grid](
        qweight.view(torch.uint8),
        scales,
        out,
        k,
        scales.shape[1],
        BN=block_n,
        BK=block_k,
        num_warps=8,
        num_stages=2,
    )
    return out
