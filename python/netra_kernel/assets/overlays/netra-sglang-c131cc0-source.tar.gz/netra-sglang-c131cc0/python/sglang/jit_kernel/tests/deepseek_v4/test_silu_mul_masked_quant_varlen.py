"""Unit test for silu_and_mul_masked_post_quant (varlen masked MoE activation).

Covers the chunked-expert-scan fix in get_work (silu_and_mul_masked_post_quant.cuh):
the kernel launches hidden_dim/8 threads per CTA, and fine-grained-MoE shapes
(e.g. Qwen3.6: intermediate 768 -> 96 threads, 128 experts) have FEWER threads
than experts, which the original single-pass masked_m scan rejected via a
host-side RuntimeCheck. The scan now walks masked_m in blockDim.x-sized chunks.

Shapes:
- deepseek-like (threads >= experts): regression for the original path
- qwen36-like  (96 threads < 128 experts): the shape that crashed dgmoe boot
- worst-case   (32 threads, 256 experts): 8 scan chunks
"""

from __future__ import annotations

import pytest
import torch

from sglang.jit_kernel.benchmark.bench_activation import register_cuda_ci
from sglang.jit_kernel.deepseek_v4 import silu_and_mul_masked_post_quant

register_cuda_ci(est_time=30, suite="stage-b-kernel-unit-1-gpu-large")

GROUP = 128
FP8_MAX = 448.0


def _reference(input_bf16: torch.Tensor, masked_m: torch.Tensor):
    """fp32 reference: per-(expert, token) silu(gate)*up, per-128-group fp8 quant."""
    E, T, D2 = input_bf16.shape
    D = D2 // 2
    gate = input_bf16[..., :D].float()
    up = input_bf16[..., D:].float()
    act = gate * torch.sigmoid(gate) * up  # [E, T, D]
    groups = act.view(E, T, D // GROUP, GROUP)
    absmax = groups.abs().amax(dim=-1).clamp_min(1e-10)  # [E, T, G]
    scale = absmax / FP8_MAX
    q = (groups / scale.unsqueeze(-1)).clamp(-FP8_MAX, FP8_MAX)
    deq = q.to(torch.float8_e4m3fn).float() * scale.unsqueeze(-1)
    return deq.view(E, T, D), scale


@pytest.mark.parametrize(
    "num_experts,intermediate,label",
    [
        (32, 2048, "deepseek_like_threads_ge_experts"),
        (256, 512, "qwen36_prod_shape_4_chunks"),  # E=256/topk8, inter 512
        (128, 768, "threads_lt_experts_odd_groups"),
        (256, 256, "worst_case_8_chunks"),
    ],
)
@pytest.mark.parametrize("topk", [8])
def test_silu_mul_masked_quant_varlen(num_experts, intermediate, label, topk):
    torch.manual_seed(0)
    device = torch.device("cuda")
    T = 64  # padded tokens per expert
    E, D = num_experts, intermediate
    G = D // GROUP

    input_bf16 = torch.randn(E, T, 2 * D, device=device, dtype=torch.bfloat16)
    # Ragged occupancy incl. zero-token experts. The kernel launches exactly
    # T*topk CTAs (the runner's invariant is sum(masked_m) <= num_tokens*topk),
    # so cap the sum to the grid budget while keeping nonzero experts in EVERY
    # scan chunk (experts >= blockDim.x are the fixed path).
    budget = T * topk
    hi = min(T, max(2, (2 * budget) // E))
    raw = torch.randint(0, hi + 1, (E,), dtype=torch.int64)
    raw[::3] = 0  # exercise empty experts inside the scan
    total = 0
    for i in range(E):
        take = min(int(raw[i]), budget - total)
        raw[i] = max(take, 0)
        total += int(raw[i])
    masked_m = raw.to(device=device, dtype=torch.int32)
    assert int(masked_m.sum()) <= budget
    assert int(masked_m[E // 2 :].sum()) > 0, "no work in later scan chunks"

    output = torch.empty(E, T, D, device=device, dtype=torch.float8_e4m3fn)
    output_scale = torch.empty(E, T, G, device=device, dtype=torch.float32)

    silu_and_mul_masked_post_quant(
        input_bf16,
        output,
        output_scale,
        GROUP,
        masked_m,
        scale_ue8m0=False,
        topk=topk,
        transposed=False,
    )
    torch.cuda.synchronize()

    ref_deq, ref_scale = _reference(input_bf16, masked_m)
    got_deq = output.float() * output_scale.repeat_interleave(GROUP, dim=-1)

    # Compare only valid (expert, token) rows.
    for e in range(E):
        m = int(masked_m[e])
        if m == 0:
            continue
        torch.testing.assert_close(
            got_deq[e, :m],
            ref_deq[e, :m],
            atol=6e-2,
            rtol=6e-2,
            msg=f"{label}: mismatch at expert {e} (masked_m={m})",
        )
    # Scales must match closely (same absmax computation modulo bf16->fp32).
    valid = torch.arange(T, device=device)[None, :] < masked_m[:, None].long()
    torch.testing.assert_close(
        output_scale[valid.unsqueeze(-1).expand(-1, -1, G)],
        ref_scale[valid.unsqueeze(-1).expand(-1, -1, G)],
        atol=1e-2,
        rtol=1e-2,
    )


if __name__ == "__main__":
    import sys

    sys.exit(pytest.main([__file__, "-v", "-x"]))
