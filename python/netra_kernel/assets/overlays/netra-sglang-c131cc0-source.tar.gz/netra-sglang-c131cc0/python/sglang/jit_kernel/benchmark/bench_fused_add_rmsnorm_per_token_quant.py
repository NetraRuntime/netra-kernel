"""
Benchmark: fused add+RMSNorm+per-token-FP8-quant vs the unfused two-kernel
path (sgl_kernel fused_add_rmsnorm + sglang_per_token_quant_fp8).

Ported from sgl-project/sglang#28101; relocated to the fork's benchmark
layout and utilities.

Run:
    python python/sglang/jit_kernel/benchmark/bench_fused_add_rmsnorm_per_token_quant.py
"""

import itertools

import torch

from sglang.jit_kernel.benchmark.utils import (
    get_benchmark_range,
    run_benchmark_no_cudagraph,
)
from sglang.jit_kernel.fused_add_rmsnorm_per_token_quant import (
    fused_add_rmsnorm_per_token_quant,
)
from sglang.srt.layers.quantization.fp8_kernel import sglang_per_token_quant_fp8
from sglang.test.ci.ci_register import register_cuda_ci

register_cuda_ci(est_time=30, suite="stage-b-kernel-benchmark-1-gpu-large")

NUM_TOKENS_RANGE = get_benchmark_range(
    full_range=[1, 4, 16, 64, 256, 1024, 4096],
    ci_range=[16, 64],
)
HIDDEN_DIM_RANGE = get_benchmark_range(
    full_range=[4096, 8192],
    ci_range=[8192],
)
EPS = 1e-6


def _unfused(x, residual, weight):
    # Two-kernel reference: AOT fused_add_rmsnorm + sgl per-token quant.
    from sgl_kernel import fused_add_rmsnorm

    fused_add_rmsnorm(x, residual, weight, EPS)
    return sglang_per_token_quant_fp8(x)


def _fused(x, residual, weight):
    return fused_add_rmsnorm_per_token_quant(x, residual, weight, eps=EPS)


def benchmark():
    print(f"{'M':>6} {'D':>6} {'unfused(us)':>12} {'fused(us)':>10} {'speedup':>8}")
    for d, m in itertools.product(HIDDEN_DIM_RANGE, NUM_TOKENS_RANGE):
        x = torch.randn(m, d, dtype=torch.bfloat16, device="cuda")
        residual = torch.randn(m, d, dtype=torch.bfloat16, device="cuda")
        weight = torch.randn(d, dtype=torch.bfloat16, device="cuda")
        # x/residual are mutated in place by both impls; numerics are
        # irrelevant for timing, so reuse the same buffers across iterations.
        t_unfused, _, _ = run_benchmark_no_cudagraph(
            lambda: _unfused(x, residual, weight)
        )
        t_fused, _, _ = run_benchmark_no_cudagraph(lambda: _fused(x, residual, weight))
        print(
            f"{m:>6} {d:>6} {t_unfused:>12.2f} {t_fused:>10.2f}"
            f" {t_unfused / t_fused:>7.2f}x"
        )


if __name__ == "__main__":
    benchmark()
