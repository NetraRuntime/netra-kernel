// SPDX-License-Identifier: MIT
// Handwritten gfx950 DSV4 control operation: rms_fp8_4096_tiny.
// ABI: sixteen 64-bit pointers followed by sixteen uint32 scalars (192 bytes).
// Caller supplies valid, non-aliasing tensors on the owning device/stream.
.amdgcn_target "amdgcn-amd-amdhsa--gfx950"
.amdhsa_code_object_version 6
.text
.protected netra_dsv4_rms_fp8_4096_tiny
.globl netra_dsv4_rms_fp8_4096_tiny
.p2align 8
.type netra_dsv4_rms_fp8_4096_tiny,@function
netra_dsv4_rms_fp8_4096_tiny:
    s_load_dwordx8 s[4:11], s[0:1], 0
    s_load_dwordx2 s[12:13], s[0:1], 32
    s_load_dwordx8 s[36:43], s[0:1], 128
    s_waitcnt lgkmcnt(0)
    // Sixteen waves cooperate on one 4096-wide row. Two 128-element
    // quantization groups per wave; inputs stay in registers between passes.
    v_lshrrev_b32 v23, 6, v0
    s_nop 4
    v_readfirstlane_b32 s62, v23
    s_nop 4
    v_and_b32 v0, 63, v0
    s_mul_i32 s60, s2, s41
    s_mul_hi_u32 s61, s2, s41
    s_add_u32 s4, s4, s60
    s_addc_u32 s5, s5, s61
    s_mul_i32 s60, s2, s37
    s_mul_hi_u32 s61, s2, s37
    s_add_u32 s8, s8, s60
    s_addc_u32 s9, s9, s61
    s_mul_i32 s60, s2, s38
    s_mul_hi_u32 s61, s2, s38
    s_add_u32 s10, s10, s60
    s_addc_u32 s11, s11, s61
    s_mul_i32 s60, s2, s40
    s_mul_hi_u32 s61, s2, s40
    s_add_u32 s12, s12, s60
    s_addc_u32 s13, s13, s61
    s_lshl_b32 s63, s62, 8
    v_lshlrev_b32 v18, 2, v0
    v_add_u32 v18, s63, v18
    v_add_u32 v19, 4096, v18
    global_load_dword v24, v18, s[4:5]
    global_load_dword v32, v18, s[6:7]
    global_load_dword v25, v19, s[4:5]
    global_load_dword v33, v19, s[6:7]
    s_waitcnt vmcnt(0)
    v_mov_b32 v3, 0
    v_lshlrev_b32 v4, 16, v24
    v_and_b32 v5, 0xffff0000, v24
    v_fma_f32 v3, v4, v4, v3
    v_fma_f32 v3, v5, v5, v3
    v_lshlrev_b32 v4, 16, v25
    v_and_b32 v5, 0xffff0000, v25
    v_fma_f32 v3, v4, v4, v3
    v_fma_f32 v3, v5, v5, v3
    s_nop 1
    v_add_f32_dpp v3, v3, v3 quad_perm:[1,0,3,2]
    s_nop 1
    v_add_f32_dpp v3, v3, v3 quad_perm:[2,3,0,1]
    s_nop 1
    v_add_f32_dpp v3, v3, v3 row_shl:4 bound_ctrl:1
    s_nop 1
    v_add_f32_dpp v3, v3, v3 row_shl:8 bound_ctrl:1
    s_nop 1
    v_mov_b32 v20, v3
    s_nop 1
    v_permlane16_swap_b32 v3, v20
    s_nop 1
    v_add_f32 v3, v3, v20
    s_nop 1
    v_mov_b32 v20, v3
    s_nop 1
    v_permlane32_swap_b32 v3, v20
    s_nop 1
    v_add_f32 v3, v3, v20
    s_nop 4
    v_readfirstlane_b32 s52, v3
    s_nop 4
    s_mov_b64 exec, 1
    s_lshl_b32 s60, s62, 2
    v_mov_b32 v2, s60
    v_mov_b32 v4, s52
    ds_write_b32 v2, v4
    s_waitcnt lgkmcnt(0)
    s_mov_b64 exec, -1
    s_barrier
    s_mov_b64 exec, 1
    v_mov_b32 v2, 0
    ds_read_b128 v[4:7], v2
    ds_read_b128 v[8:11], v2 offset:16
    ds_read_b128 v[40:43], v2 offset:32
    ds_read_b128 v[44:47], v2 offset:48
    s_waitcnt lgkmcnt(0)
    v_add_f32 v4, v4, v5
    v_add_f32 v6, v6, v7
    v_add_f32 v8, v8, v9
    v_add_f32 v10, v10, v11
    v_add_f32 v40, v40, v41
    v_add_f32 v42, v42, v43
    v_add_f32 v44, v44, v45
    v_add_f32 v46, v46, v47
    v_add_f32 v4, v4, v6
    v_add_f32 v8, v8, v10
    v_add_f32 v40, v40, v42
    v_add_f32 v44, v44, v46
    v_add_f32 v4, v4, v8
    v_add_f32 v40, v40, v44
    v_add_f32 v4, v4, v40
    v_mul_f32 v4, 0.000244140625, v4
    v_add_f32 v4, s36, v4
    v_rsq_f32 v4, v4
    v_nop
    s_nop 3
    s_nop 4
    v_readfirstlane_b32 s53, v4
    s_nop 4
    s_mov_b64 exec, -1
    v_lshlrev_b32 v4, 16, v24
    v_and_b32 v5, 0xffff0000, v24
    v_lshlrev_b32 v6, 16, v32
    v_and_b32 v7, 0xffff0000, v32
    v_mul_f32 v4, s53, v4
    v_mul_f32 v5, s53, v5
    v_mul_f32 v6, v4, v6
    v_mul_f32 v7, v5, v7
    s_cmp_eq_u32 s42, 0
    s_cbranch_scc1 .Lskip_norm0
    v_cvt_pk_bf16_f32 v9, v6, v7
    global_store_dword v18, v9, s[12:13] offset:0
.Lskip_norm0:
    v_and_b32 v8, 0x7fffffff, v6
    v_and_b32 v9, 0x7fffffff, v7
    v_max_f32 v8, v8, v9
    s_nop 1
    v_max_f32_dpp v8, v8, v8 quad_perm:[1,0,3,2]
    s_nop 1
    v_max_f32_dpp v8, v8, v8 quad_perm:[2,3,0,1]
    s_nop 1
    v_max_f32_dpp v8, v8, v8 row_shl:4 bound_ctrl:1
    s_nop 1
    v_max_f32_dpp v8, v8, v8 row_shl:8 bound_ctrl:1
    s_nop 1
    v_mov_b32 v20, v8
    s_nop 1
    v_permlane16_swap_b32 v8, v20
    s_nop 1
    v_max_f32 v8, v8, v20
    s_nop 1
    v_mov_b32 v20, v8
    s_nop 1
    v_permlane32_swap_b32 v8, v20
    s_nop 1
    v_max_f32 v8, v8, v20
    // Lanes 0..3 in each 16-lane row contain the complete maximum.
    s_nop 1
    v_max_f32_dpp v8, v8, v8 row_shr:4 bound_ctrl:1
    s_nop 1
    v_max_f32_dpp v8, v8, v8 row_shr:8 bound_ctrl:1
    s_nop 1
    v_max_f32 v8, 1.0e-10, v8
    v_mul_f32 v8, 0.002232142857142857, v8
    s_mov_b64 exec, 1
    s_add_u32 s60, s62, 0
    s_mul_i32 s60, s60, s39
    v_mov_b32 v2, s60
    global_store_dword v2, v8, s[10:11]
    s_mov_b64 exec, -1
    v_rcp_f32 v8, v8
    v_nop
    s_nop 3
    v_mul_f32 v6, v6, v8
    v_mul_f32 v7, v7, v8
    v_max_f32 v6, -448.0, v6
    v_min_f32 v6, 448.0, v6
    v_max_f32 v7, -448.0, v7
    v_min_f32 v7, 448.0, v7
    v_cvt_scalef32_pk_fp8_f32 v9, v6, v7, 1.0
    v_lshrrev_b32 v2, 1, v18
    global_store_short v2, v9, s[8:9] offset:0
    v_lshlrev_b32 v4, 16, v25
    v_and_b32 v5, 0xffff0000, v25
    v_lshlrev_b32 v6, 16, v33
    v_and_b32 v7, 0xffff0000, v33
    v_mul_f32 v4, s53, v4
    v_mul_f32 v5, s53, v5
    v_mul_f32 v6, v4, v6
    v_mul_f32 v7, v5, v7
    s_cmp_eq_u32 s42, 0
    s_cbranch_scc1 .Lskip_norm1
    v_cvt_pk_bf16_f32 v9, v6, v7
    global_store_dword v19, v9, s[12:13] offset:0
.Lskip_norm1:
    v_and_b32 v8, 0x7fffffff, v6
    v_and_b32 v9, 0x7fffffff, v7
    v_max_f32 v8, v8, v9
    s_nop 1
    v_max_f32_dpp v8, v8, v8 quad_perm:[1,0,3,2]
    s_nop 1
    v_max_f32_dpp v8, v8, v8 quad_perm:[2,3,0,1]
    s_nop 1
    v_max_f32_dpp v8, v8, v8 row_shl:4 bound_ctrl:1
    s_nop 1
    v_max_f32_dpp v8, v8, v8 row_shl:8 bound_ctrl:1
    s_nop 1
    v_mov_b32 v20, v8
    s_nop 1
    v_permlane16_swap_b32 v8, v20
    s_nop 1
    v_max_f32 v8, v8, v20
    s_nop 1
    v_mov_b32 v20, v8
    s_nop 1
    v_permlane32_swap_b32 v8, v20
    s_nop 1
    v_max_f32 v8, v8, v20
    // Lanes 0..3 in each 16-lane row contain the complete maximum.
    s_nop 1
    v_max_f32_dpp v8, v8, v8 row_shr:4 bound_ctrl:1
    s_nop 1
    v_max_f32_dpp v8, v8, v8 row_shr:8 bound_ctrl:1
    s_nop 1
    v_max_f32 v8, 1.0e-10, v8
    v_mul_f32 v8, 0.002232142857142857, v8
    s_mov_b64 exec, 1
    s_add_u32 s60, s62, 16
    s_mul_i32 s60, s60, s39
    v_mov_b32 v2, s60
    global_store_dword v2, v8, s[10:11]
    s_mov_b64 exec, -1
    v_rcp_f32 v8, v8
    v_nop
    s_nop 3
    v_mul_f32 v6, v6, v8
    v_mul_f32 v7, v7, v8
    v_max_f32 v6, -448.0, v6
    v_min_f32 v6, 448.0, v6
    v_max_f32 v7, -448.0, v7
    v_min_f32 v7, 448.0, v7
    v_cvt_scalef32_pk_fp8_f32 v9, v6, v7, 1.0
    v_lshrrev_b32 v2, 1, v18
    global_store_short v2, v9, s[8:9] offset:2048
.Ldone:
    s_endpgm
.Lend:
.size netra_dsv4_rms_fp8_4096_tiny, .Lend-netra_dsv4_rms_fp8_4096_tiny
.section .rodata,"a",@progbits
.p2align 6, 0
.amdhsa_kernel netra_dsv4_rms_fp8_4096_tiny
    .amdhsa_group_segment_fixed_size 64
    .amdhsa_private_segment_fixed_size 0
    .amdhsa_kernarg_size 192
    .amdhsa_user_sgpr_count 2
    .amdhsa_user_sgpr_kernarg_segment_ptr 1
    .amdhsa_enable_private_segment 0
    .amdhsa_system_sgpr_workgroup_id_x 1
    .amdhsa_system_sgpr_workgroup_id_y 1
    .amdhsa_system_vgpr_workitem_id 0
    .amdhsa_next_free_vgpr 48
    .amdhsa_accum_offset 48
    .amdhsa_next_free_sgpr 64
    .amdhsa_reserve_vcc 1
    .amdhsa_float_round_mode_32 0
    .amdhsa_float_denorm_mode_32 3
    .amdhsa_dx10_clamp 1
    .amdhsa_ieee_mode 1
.end_amdhsa_kernel
.amdgpu_metadata
---
amdhsa.version: [1, 2]
amdhsa.kernels:
  - .args:
      - {.name: p0, .offset: 0, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p1, .offset: 8, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p2, .offset: 16, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p3, .offset: 24, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p4, .offset: 32, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p5, .offset: 40, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p6, .offset: 48, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p7, .offset: 56, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p8, .offset: 64, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p9, .offset: 72, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p10, .offset: 80, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p11, .offset: 88, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p12, .offset: 96, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p13, .offset: 104, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p14, .offset: 112, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: p15, .offset: 120, .size: 8, .value_kind: global_buffer, .address_space: global}
      - {.name: a0, .offset: 128, .size: 4, .value_kind: by_value}
      - {.name: a1, .offset: 132, .size: 4, .value_kind: by_value}
      - {.name: a2, .offset: 136, .size: 4, .value_kind: by_value}
      - {.name: a3, .offset: 140, .size: 4, .value_kind: by_value}
      - {.name: a4, .offset: 144, .size: 4, .value_kind: by_value}
      - {.name: a5, .offset: 148, .size: 4, .value_kind: by_value}
      - {.name: a6, .offset: 152, .size: 4, .value_kind: by_value}
      - {.name: a7, .offset: 156, .size: 4, .value_kind: by_value}
      - {.name: a8, .offset: 160, .size: 4, .value_kind: by_value}
      - {.name: a9, .offset: 164, .size: 4, .value_kind: by_value}
      - {.name: a10, .offset: 168, .size: 4, .value_kind: by_value}
      - {.name: a11, .offset: 172, .size: 4, .value_kind: by_value}
      - {.name: a12, .offset: 176, .size: 4, .value_kind: by_value}
      - {.name: a13, .offset: 180, .size: 4, .value_kind: by_value}
      - {.name: a14, .offset: 184, .size: 4, .value_kind: by_value}
      - {.name: a15, .offset: 188, .size: 4, .value_kind: by_value}
    .group_segment_fixed_size: 64
    .kernarg_segment_align: 8
    .kernarg_segment_size: 192
    .max_flat_workgroup_size: 1024
    .name: netra_dsv4_rms_fp8_4096_tiny
    .private_segment_fixed_size: 0
    .sgpr_count: 64
    .sgpr_spill_count: 0
    .symbol: netra_dsv4_rms_fp8_4096_tiny.kd
    .vgpr_count: 48
    .vgpr_spill_count: 0
    .wavefront_size: 64
...
.end_amdgpu_metadata
